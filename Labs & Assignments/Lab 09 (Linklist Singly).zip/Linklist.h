// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#ifndef LINKLIST_H
#define LINKLIST_H
#include <iostream>
using namespace std;
template <typename T>
struct Node
{
  T data;
  Node<T> *next;
  Node()
  {
    next = NULL;
  }
  Node(T d)
  {
    data = d;
    next = NULL;
  }
};
template <typename T>
class Linklist
{
private:
  Node<T> *head;
  Node<T> *tail;

public:
  Linklist();
  Linklist(const Linklist<T> &);
  const Linklist<T> &operator=(const Linklist<T> &);
  ~Linklist();
  Node<T> *search(T);
  bool isEmpty();
  void insertAtHead(T);
  void insertAfter(T, T);
  void insertBefore(T, T);
  void insertAtTail(T);
  void sortedInsert(T);
  bool deleteAtTail();
  bool deleteAtHead();
  bool deleteAfter(T);
  bool deleteBefore(T);
  bool deleteAt(T);
  void print() const;
  int getLength() const;
  Node<T> *getNode(int);
  // Task 02
  Node<T> *getMiddleNode()
  {
    int middle = getLength() / 2;
    Node<T> *cur = head;
    while (middle > 0)
    {
      cur = cur->next;
      middle--;
    }
    return cur;
  }
  void reverse()
  {
    if (head->next)
    {
      Node<T> *cur = head;
      head = head->next;
      reverse();
      tail->next = cur;
      tail = tail->next;
      tail->next = NULL;
    }
  }
  // Task 03
  Linklist<T> reverseInChunk(int n)
  {
    if (n > getLength())
    {
      cout << "size must be less";
      return *this;
    }
    Linklist<T> l1, list;
    Node<T> *cur = head;
    while (cur)
    {
      for (int i = 0; i < n; i++)
      {
        if (cur)
          l1.insertAtTail(cur->data);
        else
          break;
        cur = cur->next;
      }
      l1.reverse();
      Node<T> *p = l1.head;
      while (p)
      {
        list.insertAtTail(p->data);
        p = p->next;
      }
      l1.~Linklist();
    }
    return list;
  }
  // Task 04
  void removeAllDuplicates()
  {
    if (!isEmpty())
    {
      Node<T> *cur = head->next;
      Node<T> *prev = head;
      while (cur)
      {
        if (cur->data == prev->data)
        {
          Node<T> *nextNode = cur->next;
          delete cur;
          cur = nextNode;
          prev->next = nextNode;
        }
        else
        {
          prev = cur;
          cur = cur->next;
        }
      }
    }
  }
  void merge(Linklist<T> &list1, Linklist<T> &list2)
  {
    Node<T> *h1 = list1.head;
    Node<T> *h2 = list2.head;
    while (h1 && h2)
    {
      if (h1->data <= h2->data)
      {
        insertAtTail(h1->data);
        h1 = h1->next;
      }
      else
      {
        insertAtTail(h2->data);
        h2 = h2->next;
      }
    }
    while (h1)
    {
      insertAtTail(h1->data);
      h1 = h1->next;
    }
    while (h2)
    {
      insertAtTail(h2->data);
      h2 = h2->next;
    }
  }
  // Task Home work
  void deleteAllSubSum(T sum)
  {
    Node<T> *cur = head;
    while (cur)
    {
      T a = cur->data;
      cur = cur->next;
      bool found = deleteAt(sum - a);
      if (found)
      {
        found = deleteAt(a);
        if (!found)
          insertAtHead(a);
      }
    }
  }
};
#endif
