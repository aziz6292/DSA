// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#include "Linklist.h"
template <typename T>
Linklist<T>::Linklist() : head(NULL), tail(NULL)
{
}
template <typename T>
Linklist<T>::Linklist(const Linklist<T> &obj) : Linklist()
{
    if (obj.head)
    {
        Node<T> *temp = obj.head;
        while (temp)
        {
            insertAtTail(temp->data);
            temp = temp->next;
        }
    }
}
template <typename T>
const Linklist<T> &Linklist<T>::operator=(const Linklist<T> &obj)
{
    if (this == &obj)
        return *this;
    if (!isEmpty())
    {
        this->~Linklist();
    }
    Node<T> *temp = obj.head;
    while (temp)
    {
        insertAtTail(temp->data);
        temp = temp->next;
    }
    return *this;
}
template <typename T>
Linklist<T>::~Linklist()
{
    Node<T> *cur = head;
    while (head != NULL)
    {
        head = head->next;
        delete cur;
        cur = head;
    }
    tail = NULL;
}
template <typename T>
Node<T> *Linklist<T>::search(T key)
{
    Node<T> *cur = head;
    if (!isEmpty())
        while (cur != NULL)
        {
            if (cur->data == key)
                return cur;
            cur = cur->next;
        }
    return cur;
}
template <typename T>
bool Linklist<T>::isEmpty()
{
    if (head == NULL)
        return true;
    return false;
}
template <typename T>
void Linklist<T>::insertAtHead(T value)
{
    Node<T> *cur = new Node<T>(value);
    if (isEmpty())
    {
        head = cur;
        tail = cur;
    }
    else
    {
        Node<T> *temp = head;
        head = cur;
        head->next = temp;
    }
}
template <typename T>
void Linklist<T>::insertAfter(T key, T value)
{
    Node<T> *cur = search(key);
    if (cur == NULL)
        insertAtHead(value);
    else if (cur == tail)
        insertAtTail(value);
    else
    {
        Node<T> *temp = new Node<T>(value);
        temp->next = cur->next;
        cur->next = temp;
    }
}
template <typename T>
void Linklist<T>::insertBefore(T key, T value)
{
    if (!isEmpty() && head->data != key)
    {
        Node<T> *cur = head->next;
        Node<T> *prev = head;
        while (cur != NULL)
        {
            if (cur->data == key)
            {
                Node<T> *temp = new Node<T>(value);
                prev->next = temp;
                temp->next = cur;
                return;
            }
            prev = cur;
            cur = cur->next;
        }
    }
    else
        insertAtHead(value);

    // -------------------------------------------->
    // Method : 2
    //
    // Node<T> *cur = search(key);
    // if (cur == NULL || cur == head)
    //     insertAtHead(value);
    // else
    // {
    //     Node<T> *prev = head;
    //     Node<T> *temp = new Node<T>(value);
    //     while (prev->next != cur)
    //         prev = prev->next;
    //     temp->next = cur;
    //     prev->next = temp;
    // }
}
template <typename T>
void Linklist<T>::insertAtTail(T value)
{
    Node<T> *cur = new Node<T>(value);
    if (isEmpty())
        head = tail = cur;
    else
    {
        tail->next = cur;
        tail = cur;
    }
}
template <typename T>
void Linklist<T>::sortedInsert(T val)
{
    if (!isEmpty())
    {
        Node<T> *cur = head;
        Node<T> *prev = NULL;
        while (cur)
        {
            if (cur->data >= val)
            {
                if (!prev)
                    insertAtHead(val);
                else
                {
                    Node<T> *newNode = new Node<T>(val);
                    prev->next = newNode;
                    newNode->next = cur;
                }
                return;
            }
            prev = cur;
            cur = cur->next;
        }
        insertAtTail(val);
    }
    else
        insertAtHead(val);
}
template <typename T>
bool Linklist<T>::deleteAtTail()
{
    if (!isEmpty())
    {
        Node<T> *cur = head;
        if (cur == tail)
        {
            delete cur;
            head = NULL;
            tail = NULL;
        }
        else
        {
            while (cur->next != tail)
                cur = cur->next;
            delete tail;
            tail = cur;
            tail->next = NULL;
        }
        return true;
    }
    return false;
}
template <typename T>
bool Linklist<T>::deleteAtHead()
{
    if (!isEmpty())
    {
        Node<T> *cur = head;
        if (cur == tail)
        {
            delete cur;
            head = NULL;
            tail = NULL;
        }
        else
        {
            head = head->next;
            delete cur;
        }
        return true;
    }
    return false;
}
template <typename T>
bool Linklist<T>::deleteAfter(T key)
{
    Node<T> *cur = search(key);
    if (cur != NULL)
    {
        if (cur == tail)
        {
            return false;
        }
        else if (cur->next == tail)
        {
            delete tail;
            tail = cur;
            tail->next = NULL;
            return true;
        }
        else if (cur == head)
        {
            Node<T> *temp = head->next;
            head->next = temp->next;
            delete temp;
            temp = NULL;
            return true;
        }
        else
        {
            Node<T> *temp = cur->next;
            cur->next = temp->next;
            delete temp;
            temp = NULL;
            return true;
        }
    }
    else
    {
        return false;
    }
}
template <typename T>
bool Linklist<T>::deleteBefore(T key)
{
    Node<T> *cur = head->next;
    Node<T> *prev = head;
    if (head->data == key)
    {
        return false;
    }
    else if (cur->data == key)
    {
        delete head;
        head = cur;
        return true;
    }
    else
    {
        while (cur->next != NULL)
        {
            if (cur->next->data == key)
            {
                prev->next = cur->next;
                delete cur;
                return true;
            }
            prev = prev->next;
            cur = cur->next;
        }
        return false;
    }

    // ---------------------------------------------------------------->
    // next method
    // Node<T> *cur = search(key);
    // if (cur != NULL)
    // {
    //     if (cur == head)
    //     {
    //         cout << "No Node found before " << key << endl;
    //         return;
    //     }
    //     else if (head->next == cur)
    //     {
    //         delete head;
    //         head = cur;
    //     }
    //     else
    //     {
    //         Node<T> *temp = head->next;
    //         Node<T> *prev = head;
    //         while (temp->next != cur)
    //         {
    //             prev = temp;
    //             temp = temp->next;
    //         }
    //         prev->next = temp->next;
    //         delete temp;
    //     }
    // }
    // else
    // {
    //     cout << "Error: No Node found for " << key << endl;
    // }
}
template <typename T>
bool Linklist<T>::deleteAt(T key)
{
    Node<T> *cur = head;
    if (cur != NULL)
    {
        if (cur == head && cur == tail && cur->data == key)
        {
            delete cur;
            head = tail = cur = NULL;
            return true;
        }
        else if (cur == head && cur->data == key)
        {
            head = head->next;
            delete cur;
            cur = NULL;
            return true;
        }
        else
        {
            Node<T> *prev = head;
            if (head->next)
            {
                Node<T> *cur = head->next;
                while (cur)
                {
                    if (cur->data == key)
                    {
                        prev->next = cur->next;
                        return true;
                    }
                    prev = cur;
                    cur = cur->next;
                }
            }
            return false;
        }
    }
    else
        return false;
}
template <typename T>
void Linklist<T>::print() const
{
    Node<T> *cur = head;
    while (cur != NULL)
    {
        cout << cur->data << " ";
        cur = cur->next;
    }
    cout << endl;
}
template <typename T>
int Linklist<T>::getLength() const
{
    Node<T> *cur = head;
    int count = 0;
    while (cur != NULL)
    {
        cur = cur->next;
        count++;
    }
    return count;
}
template <typename T>
Node<T> *Linklist<T>::getNode(int n)
{
    if (n > getLength())
    {
        cout << " Error: Length is less than " << n << endl;
    }
    else
    {
        Node<T> *cur = head;
        int count = 0;
        while (cur != NULL)
        {
            if (count == n)
                return cur;
            cur = cur->next;
            count++;
        }
    }
}