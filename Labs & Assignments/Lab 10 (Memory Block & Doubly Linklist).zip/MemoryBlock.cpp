// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#include <iostream>
using namespace std;
class MemoryBlock
{
    friend class MemoryManager;
    int address;
    int length;
    MemoryBlock *next;
    MemoryBlock *prev;

public:
    MemoryBlock(int size, int add) : address(add), length(size), next(NULL), prev(NULL)
    {
    }
    void print()
    {
        cout << "MemoryBlock Length: " << length << "\t";
        cout << "Starting address: " << address << endl;
    }
};
class MemoryManager
{
    friend class MemoryBlock;
    MemoryBlock *head;

public:
    MemoryManager() : head(NULL){};
    MemoryBlock allocate(int size)
    {
        MemoryBlock *cur = head;
        MemoryBlock *prev = NULL, newNode(0, 0);

        if (head == NULL)
            return newNode;
        if (head->next == NULL && head->length > size)
        {
            MemoryBlock temp(size, head->address);
            head->length -= size;
            head->address += size;
            return temp;
        }
        else if (head->next == NULL && head->length == size)
        {
            MemoryBlock temp(size, head->address);
            delete head;
            head = NULL;
            return temp;
        }
        else if (head->next == NULL && head->length < size)
            return newNode;
        while (cur)
        {
            if (cur->length >= size)
            {
                if (size == cur->length)
                {
                    prev->next = cur->next;
                    cur->next->prev = prev;
                    cur->next = NULL;
                    cur->prev = NULL;
                    return *cur;
                }
                else
                {
                    MemoryBlock newBlock(size, cur->address);
                    cur->length -= size;
                    cur->address += size;
                    return newBlock;
                }
            }
            prev = cur;
            cur = cur->next;
        }
        cout << "Enough Free space not found\n";
        return newNode;
    }
    void free(MemoryBlock block)
    {
        if (head == NULL)
        {
            head = new MemoryBlock(block.length, block.address);
            head->next = NULL;
            head->prev = NULL;
            return;
        }
        else if (head->next == NULL)
        {
            if (head->address < block.address)
            {
                if (head->length == block.address)
                    head->length += block.length;
                else
                {
                    MemoryBlock *newBlock = new MemoryBlock(block.length, block.address);
                    newBlock->prev = head;
                    head->next = newBlock;
                    newBlock->next = NULL;
                }
            }
            else if (head->address > block.address)
            {
                if (head->address == block.length + block.address)
                {
                    head->address = block.address;
                    head->length += block.length;
                }
                else
                {
                    MemoryBlock *newBlock = new MemoryBlock(block.length, block.address);
                    newBlock->next = head;
                    head->prev = newBlock;
                    head = newBlock;
                }
            }
            return;
        }
        else if (head->next)
        {
            if (head->address > block.address)
            {
                if (head->address == block.length + block.address)
                {
                    head->address = block.address;
                    head->length += block.length;
                }
                else
                {
                    MemoryBlock *newBlock = new MemoryBlock(block.length, block.address);
                    newBlock->next = head;
                    head->prev = newBlock;
                    head = newBlock;
                }
                return;
            }
        }
        MemoryBlock *cur = head;
        MemoryBlock *pre = NULL;
        while (cur)
        {
            if (cur->address > block.address)
            {
                if (pre && (pre->address + pre->length == block.address) && (cur->address == (block.address + block.length)))
                {
                    // cout << "1";
                    pre->length += block.length + cur->length;
                    pre->next = NULL;
                    delete cur;
                    cur = NULL;
                }
                else if (pre && pre->address + pre->length == block.address && cur->address > (block.address + block.length))
                {
                    // cout << "2";
                    pre->length += block.length;
                }
                else if (pre && pre->address + pre->length < block.address && cur->address == (block.address + block.length))
                {
                    // cout << "3";
                    cur->address = block.address;
                    cur->length += block.length;
                }
                else if (pre && pre->address + pre->length < block.address && cur->address > (block.address + block.length))
                {
                    // cout << "4";
                    MemoryBlock *newBlock = new MemoryBlock(block.length, block.address);
                    newBlock->next = cur;
                    newBlock->prev = pre;
                    cur->prev = newBlock;
                    pre->next = newBlock;
                }
                else
                {
                    cout << "Invalid size OR Node\n";
                }
                return;
            }
            pre = cur;
            cur = cur->next;
        }
        MemoryBlock *newBlock = new MemoryBlock(block.length, block.address);
        newBlock->prev = pre;
        pre->next = newBlock;
    }
    void printList()
    {
        MemoryBlock *temp = head;
        while (temp)
        {
            temp->print();
            temp = temp->next;
        }
    }
    ~MemoryManager()
    {
        while (head)
        {
            head = head->next;
            delete head->prev;
            head->prev == NULL;
        }
    }
};
int main()
{
    MemoryManager pool;
    while (true)
    {
        cout << "1.\tFree space\n2.\tAllocate memory\n3.\tPrint pool\n4.\tExit\nSelect: ";
        char choice;
        cin >> choice;
        while (choice < '1' || choice > '4')
        {
            cout << choice << " is not a valid choice!!\nRe-enter the choice: ";
            cin >> choice;
        }
        cout << endl
             << endl;
        if (choice == '4')
            exit(0);
        else if (choice == '1')
        {
            int length, address;
            cout << "Enter length: ";
            cin >> length;
            while (length <= 0 || length > INT16_MAX)
            {
                cout << length << " is not a valid Length!!\nRe-enter the Length: ";
                cin >> length;
            }
            cout << "Enter address: ";
            cin >> address;
            while (length < 0 || length > INT16_MAX)
            {
                cout << address << " is not a valid address!!\nRe-enter the address: ";
                cin >> address;
            }
            MemoryBlock block(length, address);
            pool.free(block);
        }
        else if (choice == '2')
        {
            int length;
            cout << "Enter length: ";
            cin >> length;
            while (length <= 0 || length > INT16_MAX)
            {
                cout << length << " is not a valid Length!!\nRe-enter the Length: ";
                cin >> length;
            }
            MemoryBlock newBlock = pool.allocate(length);
            newBlock.print();
        }
        else
        {
            pool.printList();
        }
        cout << endl
             << endl;
    }
    return 0;
}