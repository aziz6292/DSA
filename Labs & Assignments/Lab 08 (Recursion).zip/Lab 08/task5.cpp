//  Abdul Aziz
//  BCSF19A026
//  CS-Afternoon
#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

int count_character(char *, char, int);
int count_character(char *, char);

int main()
{
    string st;
    cout << "Enter string: ";
    getline(cin, st);
    char *str = new char[st.size() + 1];
    for (int i = 0; i < st.size(); i++)
        str[i] = st[i];
    char ch;
    cout << "Enter character to count: ";
    cin.get(ch);
    cout << count_character(str, ch) << endl;
    delete[] str;
    str = NULL;
    return 0;
}
int count_character(char *str, char c, int i)
{
    if (i >= strlen(str))
        return 0;
    else
    {
        if (str[i] == c)
            return 1 + count_character(str, c, i + 1);
        else
            return 0 + count_character(str, c, i + 1);
    }
}
int count_character(char *str, char c)
{
    return count_character(str, c, 0);
}