//  Abdul Aziz
//  BCSF19A026
//  CS-Afternoon
#include <iostream>
using namespace std;

int sumDigits(int);

int main()
{

    cout << "Enter num: ";
    int num;
    cin >> num;
    while (num < INT16_MIN || num > INT16_MAX)
    {
        cout << "Re-enter: ";
        cin >> num;
    }
    cout << "Sum of digit: " << sumDigits(num) << endl;
    return 0;
}
int sumDigits(int num)
{
    if (num >= -9 && num <= 9)
    {
        return num;
    }
    else
    {
        return num % 10 + sumDigits(num / 10);
    }
}