//  Abdul Aziz
//  BCSF19A026
//  CS-Afternoon
#include <iostream>
using namespace std;

void print(int, int, int);
void print(int);
int find(int, int, int);
int find(int);

int main()
{
    cout << "Enter term of series: ";
    int n;
    cin >> n;
    while (n < 0 || n > INT16_MAX)
    {
        cout << "re-enter: ";
        cin >> n;
    }
    print(n);
    cout << "Now Enter nth number of the series above to find: ";
    cin >> n;
    cout << find(n);
    return 0;
}

void print(int i, int sum, int n)
{
    if (i < n)
    {
        cout << sum << ", ";
        i++;
        sum = sum + i;
        print(i, sum, n);
    }
}
void print(int n)
{
    print(0, 0, n);
    cout << "......\n";
}
int find(int i, int sum, int n)
{
    if (i < n - 1)
    {
        i++;
        sum = sum + i;
        return find(i, sum, n);
    }
    else
        return sum;
}
int find(int n)
{
    return find(0, 0, n);
}