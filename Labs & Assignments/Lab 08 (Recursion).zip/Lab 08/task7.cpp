//  Abdul Aziz
//  BCSF19A026
//  CS-Afternoon
#include <iostream>
using namespace std;

void printBase(int , int);
int main()
{
    cout <<"Enter num: ";
    int num ;
    cin >> num; 
    while ( num  < 0  || num > INT16_MAX )
    {
        cout <<"re-enter: ";
        cin>>num;
    }
    cout <<"Enter base: ";
    int ba;
    cin>>ba;
    while ( ba < 2 || ba > 9)
    {
       cout <<"Re-enter: ";
       cin>>ba;
    }
    printBase (ba, num);
    return 0;
}
void printBase (int base, int n)
{
    if (n)
    {
        printBase ( base, n/base);
        cout << n%base;
    }
}