//  Abdul Aziz
//  BCSF19A026
//  CS-Afternoon
#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

void replace(char *, char, char, int);
void replace(char *, char, char);

int main()
{
    string st;
    cout << "Enter string: ";
    getline(cin, st);
    char *str = new char[st.size() + 1];
    for (int i = 0; i < st.size(); i++)
        str[i] = st[i];
    char from, to;
    cout << "Enter from: ";
    cin.get(from);
    cout << "Enter to: ";
    cin.ignore();
    cin.get(to);
    replace(str, from, to);
    cout << str << endl;
    delete[] str;
    str = NULL;
    return 0;
}
void replace(char *str, char from, char to, int i)
{
    if (i < strlen(str))
    {
        if (str[i] == from)
            str[i] = to;
        replace(str, from, to, i + 1);
    }
}
void replace(char *str, char from, char to)
{
    replace(str, from, to, 0);
}