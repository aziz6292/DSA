//  Abdul Aziz
//  BCSF19A026
//  CS-Afternoon
#include <iostream>
using namespace std;

long long evenDigits(long long);

int main()
{
    cout << "Enter num: ";
    long long num;
    cin >> num;
    while (num < INT64_MIN || num > INT64_MAX)
    {
        cout << "Re-enter:  ";
        cin >> num;
    }
    cout << "Even: " << evenDigits(num) << endl;
    return 0;
}
long long evenDigits(long long num)
{
    if (num >= -9 && num <= 9)
    {
        if (num % 2 == 0)
            return num;
        else
            return 0;
    }
    else
    {
        int i = evenDigits(num / 10);
        if ((num % 10) % 2 == 0)
            return (i * 10) + num % 10;
        else
            return i;
    }
}