//  Abdul Aziz
//  BCSF19A026
//  CS-Afternoon
#include <iostream>
#include <stack>
using namespace std;

template <typename T>
void reverse(stack<T> &, T, int);
template <typename T>
void reverse(stack<T> &, int);
template <typename T>
void reverse(stack<T> &);

int main()
{
    stack<int> st;
    for (int i = 1; i < 10; i++)
        st.push(i);
    reverse(st);
    cout << "After reversing:\n";
    while (!st.empty())
    {
        cout << st.top() << " ";
        st.pop();
    }
    return 0;
}
template <typename T>
void reverse(stack<T> &st, T a, int i)
{
    if (i == st.size())
        st.push(a);
    else
    {
        int j = st.top();
        st.pop();
        reverse(st, a, i);
        st.push(j);
    }
}
template <typename T>
void reverse(stack<T> &st, int i)
{
    if (i < st.size())
    {
        T a = st.top();
        st.pop();
        reverse(st, a, i);
        reverse(st, i + 1);
    }
}
template <typename T>
void reverse(stack<T> &st)
{
    reverse(st, 0);
}