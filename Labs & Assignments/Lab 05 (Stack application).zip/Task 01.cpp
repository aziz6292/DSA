// Abdul Aziz
// BCSF19A026 Add/Drop
// CS Afternoon
#include<iostream>
#include <stack>
using namespace std;
template <class T>
class Enqueu
{
    stack<T> arr;

public:
    T dequeue()
    {
        stack<T> temp;
        while (!arr.empty())
        {
            temp.push(arr.top());
            arr.pop();
        }

        T val = temp.top();
        temp.pop();
        while (!temp.empty())
        {
            arr.push(temp.top());
            temp.pop();
        }
        return val;
    }
    void enqueue(T val)
    {
        arr.push(val);
    }
};

int main()
{
    Enqueu<int> a;
    for (int i = 0; i < 5; i++)
        a.enqueue(i);
        a.enqueue(20);
        cout <<a.dequeue()<<" ";
    for (int j = 0; j < 5; j++)
        cout << a.dequeue() << " ";
    cout << endl;
    return 0;
}
