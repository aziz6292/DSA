// Abdul Aziz
// BCSF19A026 Add/Drop
// CS Afternoon
#include <iostream>
#include <stack>
using namespace std;

template <class T>
void sort(stack<T> &arr)
{
    stack<T> temp;
    T a, b;
    int swapCount = 0;
    do
    {
        b = arr.top();
        arr.pop();
        while (!arr.empty())
        {
            a = arr.top();
            arr.pop();

            if (a > b)
            {
                swap(a, b);
            }
            temp.push(a);
        }
        temp.push(b);
        while (!temp.empty())
        {
            arr.push(temp.top());
            temp.pop();
        }
        swapCount++;
    } while (swapCount < arr.size());
}
int main()
{
    stack<int> arr;
    arr.push(5);
    arr.push(8);
    arr.push(-3);
    arr.push(7);
    arr.push(-10);
    arr.push(20);
    sort(arr);
    cout <<"\nAfter Sorting: ";
    while (!arr.empty())
    {
        cout << arr.top()<<" ";
        arr.pop();
    }
    cout <<endl;
    return 0;
}