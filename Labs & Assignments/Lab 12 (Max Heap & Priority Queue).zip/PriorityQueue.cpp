//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#include "PriorityQueue.h"

template <typename T>
void PriorityQueue<T>::reSize(int size)
{
    if (size <= 0 || maxSize == 0)
        size = 1;
    T *tempHeap = new T[size]{};
    for (int i = 0; i < curSize; i++)
        tempHeap[i] = heap[i];
    int tempCount = curSize;
    this->~PriorityQueue();
    heap = tempHeap;
    maxSize = size;
    curSize = tempCount;
    tempHeap = NULL;
}
template <typename T>
PriorityQueue<T>::PriorityQueue(int size)
{
    maxSize = size;
    curSize = 0;
    if (size > 0)
        heap = new T[maxSize + 1]{};
    else
    {
        maxSize = 0;
        heap = NULL;
    }
}
template <typename T>
PriorityQueue<T>::PriorityQueue(const PriorityQueue<T> &obj)
{
    maxSize = obj.maxSize;
    curSize = obj.curSize;
    heap = new T[maxSize]{};
    for (int i = 0; i < curSize; i++)
        heap[i] = obj.heap[i];
}
template <typename T>
const PriorityQueue<T> &PriorityQueue<T>::operator=(const PriorityQueue<T> &obj)
{
    if (this == &obj)
        return *this;
    if (heap)
        this->~PriorityQueue();
    maxSize = obj.maxSize;
    curSize = obj.curSize;
    heap = new T[maxSize]{};
    for (int i = 0; i < curSize; i++)
        heap[i] = obj.heap[i];
    return *this;
}
template <typename T>
PriorityQueue<T>::~PriorityQueue()
{
    if (heap)
    {
        delete[] heap;
        heap = NULL;
    }
}
template <typename T>
void PriorityQueue<T>::insertProject(T val)
{
    if (isFull())
        reSize(maxSize * 2);
    int i = curSize;
    while (i && ((i - 1) / 2 >= 0) && (heap[(i - 1) / 2] < val))
    {
        heap[i] = heap[i / 2];
        i = i / 2;
    }
    curSize++;
    heap[i] = val;
}
template <typename T>
int PriorityQueue<T>::searchProject(string name)
{
    for (int i = 0; i < curSize; i++)
        if (heap[i].getName() == name)
        {
            cout <<"Project found\n";
            heap[i].display();
            return i;
        }
    cout << "Project " << name << " Not Found" << endl;
    return -1;
}
template <typename T>
bool PriorityQueue<T>::getNextProject()
{
    if (isEmpty())
        return false;
    if (curSize == maxSize / 4)
        reSize(maxSize / 2);
    heap[0] = heap[--curSize];
    int largest = 0, left, right, i = 0;
    bool isRemoved = false;
    while (!isRemoved && i * 2 + 1 < curSize)
    {
        left = 2 * i + 1;
        right = 2 * i + 2;
        if (heap[left] > heap[largest])
            largest = left;
        if (right < curSize && heap[right] > heap[largest])
            largest = right;
        if (largest == i)
            isRemoved = true;
        else
        {
            swap(i, largest);
            i = largest;
        }
    }
    return isRemoved;
}
template <typename T>
bool PriorityQueue<T>::getSpecificProject(string name)
{
    for (int i = 0; i < curSize; i++)
    {
        if (heap[i].getName() == name)
        {
            increaseProjectPriority(i);
            heap[0].display();
            getNextProject();
            cout <<"successfully pop out" << endl;
            return true;
        }
    }
    cout << "Project " << name << " Not found in heap" << endl;
    return false;
}
template <typename T>
void PriorityQueue<T>::decreaseProjectPriority(int i)
{
    if (i < 0 || i > curSize)
    {
        cout << "Invalid index\n";
        return;
    }
    // swapping Project
    swap(i, curSize - 1);
    // Now swapping priority back
    int tempID = heap[i].getID();
    heap[i].setID(heap[curSize - 1].getID());
    heap[curSize - 1].setID(tempID);
}
template <typename T>
void PriorityQueue<T>::increaseProjectPriority(int i)
{
    if (i < 0 || i > curSize)
    {
        cout << "Invalid index\n";
        return;
    }
    // swapping Project
    swap(i, 0);
    // Now swapping priority back
    int tempID = heap[i].getID();
    heap[i].setID(heap[0].getID());
    heap[0].setID(tempID);
}
template <typename T>
void PriorityQueue<T>::displayAllProjects()
{
    for (int i = 0; i < curSize; i++)
    {
        heap[i].display();
        cout << endl;
    }
}
template <typename T>
int PriorityQueue<T>::getLeftChild(int i)
{
    if (i < 0 || i * 2 + 1 >= curSize)
    {
        cout << "Left Child does not exist\n";
        return -1;
    }
    return i * 2 + 1;
}
template <typename T>
int PriorityQueue<T>::getRightChild(int i)
{
    if (i < 0 || i * 2 + 2 >= curSize)
    {
        cout << "Right child does not exist\n";
        return -1;
    }
    return i * 2 + 2;
}
template <typename T>
int PriorityQueue<T>::getParent(int i)
{
    if (i < 1 || i > curSize - 1)
    {
        cout << "Parent does not exist\n";
        return -1;
    }
    return (i - 1) / 2;
}
template <typename T>
void PriorityQueue<T>::swap(int i, int j)
{

    if (i >= 0 && i < curSize && j >= 0 && j < curSize)
    {
        Project tempProject = heap[i];
        heap[i] = heap[j];
        heap[j] = tempProject;
    }
    else
        cout << "Invalid index\n";
}
template <typename T>
int PriorityQueue<T>::getNodeCount()
{
    return curSize;
}

template <typename T>
bool PriorityQueue<T>::isEmpty()
{
    return curSize == 0;
}
template <typename T>
bool PriorityQueue<T>::isFull()
{
    return curSize == maxSize;
}

template <typename T>
T PriorityQueue<T>::getMaxProject()
{
    return heap[0];
}
