//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#ifndef PRIORITY_QUEUE
#define PRIORITY_QUEUE
#include "Project.h"
template <typename T>
class PriorityQueue
{
    T *heap;
    int curSize;
    int maxSize;
    void reSize(int);

public:
    PriorityQueue(int = 0);
    PriorityQueue(const PriorityQueue<T> &);
    const PriorityQueue<T> &operator=(const PriorityQueue<T> &);
    ~PriorityQueue();
    void insertProject(T);
    bool getNextProject();
    int searchProject(string);
    bool getSpecificProject(string);
    void decreaseProjectPriority(int);
    void increaseProjectPriority(int);
    void displayAllProjects();
    int getLeftChild(int);
    int getRightChild(int);
    int getParent(int);
    void swap(int, int);
    int getNodeCount();
    T getMaxProject();
    bool isEmpty();
    bool isFull();
};
#endif