//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#include "PriorityQueue.cpp"

int main()
{
    Project tempProject;
    PriorityQueue<Project> list;
    cout << "*****************************" << endl;
    cout << "********* WELCOME  **********" << endl;
    cout << "*****************************" << endl;
    while (true)
    {
        cout << "Please select from the following options .....\n";
        cout << "1.\tpush new project\n2.\tpop next project\n3.\tsearch project by name\n";
        cout << "4.\tpop specified project\n5.\tget number of projects pending\n";
        cout << "6.\tget project index (left,right,parent)\n7.\tincrease priority of project\n";
        cout << "8.\tdecrease priority of project\n9.\tdisplay all projects\n0.\texit\nyour selection: ";
        char choice;
        cin >> choice;
        while (choice < '0' || choice > '9')
        {
            cout << "Your choice " << choice << " is invalid\n";
            cout << "Please enter a valid choice (0-9): ";
            cin >> choice;
        }
        if (choice == '0')
            exit(0);
        else if (choice == '1')
        {
            tempProject.setProject();
            list.insertProject(tempProject);
        }
        else if (choice == '2')
        {
            tempProject = list.getMaxProject();
            tempProject.display();
            list.getNextProject();
        }
        else if (choice == '3')
        {
            string name;
            cout << "Enter name of project to search: ";
            cin.ignore();
            getline(cin, name);
            list.searchProject(name);
        }
        else if (choice == '4')
        {
            string name;
            cout << "Enter name of project to pop out: ";
            cin.ignore();
            getline(cin, name);
            list.getSpecificProject(name);
        }
        else if (choice == '5')
        {
            cout << list.getNodeCount() << " Project pending\n";
        }
        else if (choice == '6')
        {
            int index;
            cout << "Enter index of project: ";
            cin >> index;
            int left = list.getLeftChild(index);
            int right = list.getRightChild(index);
            int parent = list.getParent(index);
            if (left != -1)
                cout << "Left child is at index " << left << endl;
            if (right != -1)
                cout << "Right child is at index " << right << endl;
            if (parent != -1)
                cout << "Parent is at index " << parent << endl;
        }
        else if ( choice == '7')
        {
            int index;
            cout << "Enter index of project: ";
            cin >> index;
            list.increaseProjectPriority(index);
        }
        else if ( choice == '8')
        {
            int index;
            cout << "Enter index of project: ";
            cin >> index;
            list.decreaseProjectPriority(index);
        }
        else 
        {
            list.displayAllProjects();
        }
        cout <<endl<<endl<<"press any key to continue...";
        system("pause>0");
        system("cls");
    }
    return 0;
}