//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#ifndef PROJECT_H
#define PROJECT_H
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
class Project
{
    int projectID;
    string projectName;
    string teamLead;
    string rollNumber;

public:
    Project(int = 0, string = "", string = "", string = "");
    bool operator<(Project);
    bool operator>=(Project);
    bool operator>(Project);
    bool operator<=(Project);
    bool operator==(Project);
    bool operator!=(Project);
    int getID();
    void setID(int);
    string getName();
    void setProject();
    void display();
};
#endif
