//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************

#include "Project.h"
Project::Project(int id, string name, string team, string rollNo) : projectID(id), projectName(name), teamLead(team), rollNumber(rollNo)
{
    if (id < 0 || id > 999)
        id = 0;
}
bool Project::operator<(Project p)
{
    return projectID < p.projectID;
}
bool Project::operator>(Project p)
{
    return projectID > p.projectID;
}
bool Project::operator<=(Project p)
{
    return projectID <= p.projectID;
}
bool Project::operator>=(Project p)
{
    return projectID >= p.projectID;
}
bool Project::operator==(Project p)
{
    return projectID == p.projectID;
}
bool Project::operator!=(Project p)
{
    return !(projectID == p.projectID);
}
string Project::getName()
{
    return projectName;
}
int Project::getID()
{
    return projectID;
}
void Project::setID(int id)
{
    while (id < 0 || id > 999)
    {
        cout << "Enter valid project ID: ";
        cin >> id;
    }
    projectID = id;
}
void Project::setProject()
{
    cout << "Enter Project ID: ";
    cin >> projectID;
    while (projectID < 0 || projectID > 999)
    {
        cout << "Re-enter Project ID (000-999): ";
        cin >> projectID;
    }
    cin.ignore();
    cout << "Enter Project Name: ";
    getline(cin, projectName);
    cout << "Enter team Leader: ";
    getline(cin, teamLead);
    cout << "Enter Roll Number: ";
    getline(cin, rollNumber);
}
void Project::display()
{
    cout << setw(5) << projectID << setw(20) << projectName << setw(20) << teamLead << setw(15) << rollNumber << endl;
}
