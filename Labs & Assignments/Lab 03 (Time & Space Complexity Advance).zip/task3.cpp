#include <iostream>
using namespace std;

int gcd(int n, int m)
{
    int temp;
    if (n<m)
    {
        while (n > 0 && m%n != 0)
        {
            temp = n;
            n = m%n;
            m = temp;
        }
        if (n)
        return n;
        else
        return 1;
    }
    else 
    {
        while (m > 0 && n%m != 0)
        {
           temp = m;
           m = n%m;
           n = temp;
        }
        if (m)
        return m;
        else
        return 1;
    }
}
int main()
{
    cout <<"Enter 2 no to find GCD: ";
    int n, m;
    cin>>n>>m;
    while (!n || !m)
    {
        cout <<"Re-enter: ";
        cin>>n>>m;
    }
    cout <<"\nGCD of "<<n<<" "<<m<<" is: "<<gcd(n,m)<<endl;
    return 0;
}