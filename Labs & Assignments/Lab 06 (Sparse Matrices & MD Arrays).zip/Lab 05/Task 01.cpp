//Abdul Aziz 
//BCSF19A026
//Add-Drop
#include <iostream>
using namespace std;

void rowMajorND(int);
int main()
{
    while (true)
    {
        int n = 0;
        cout << "Enter Dimension: ";
        cin >> n;
        while ( n < 1) //validation for Dimensions
        {
            cout <<"ERROR!! Invalid Dimension";
            cout <<"\nRe-enter a positive (Dimension > 0): ";
            cin>>n;
        }
        rowMajorND(n);// calling to print formula for row major
        cout << endl;
        //Asking to check for another input
        cout << "\n\nEnter 'Q' to quit OR any key to continue..... \n";
        char ch;
        cin >> ch;
        if (toupper(ch) == 'Q')
            exit(0);
        system("cls"); // to clear the previous console screen 
    }
    return 0;
}
void rowMajorND(int dimensions)
{
    cout <<"\n\t\t";
    for (int i = 0; i < dimensions; i++) 
    {
        cout << "i" << i + 1;
        for (int j = i + 2; j <= dimensions; j++) 
            cout << "*D" << j;
        if (i + 1 < dimensions) // to prevent the + at the end we skip last iteration at this point 
            cout << " + ";
    }
}
