#ifndef STACK_H
#define STACK_H
#include <iostream>
#include <string>
#include <cctype>
#include <cstring>
using namespace std;
template <typename T>
class Stack
{
private:
    /* data */
    T *data;
    int capacity;
    int top;
    void reSize(int);

public:
    Stack();
    Stack(const Stack<T> &);
    Stack<T> &operator=(const Stack<T> &);
    ~Stack();
    // Functions
    void push(T);
    T pop();
    T stackTop();
    bool isFull();
    bool isEmpty();
    int getCapacity();
    int getNumberOfElement();
};
#endif