#include "Stack.h"
#include "Stack.cpp"
bool check(string);

int main()
{
    Stack<int> stack{};
    for (int i = 0; i < 10; i++)
        stack.push(i);
    for (int i = 0; i < 10; i++)
        cout << stack.pop() << " ";

    string str;
    // Task 01
    cout << "\n\nEnter the Mathematical Expression: ";
    getline(cin, str);
    if (check(str))
        cout << "Balanced\n";
    else
        cout << "Not Balanced\n";
    // Task 02
    string a, b;
    cout << "Enter first number: ";
    cin >> a;
    cout << "Enter second number: ";
    cin >> b;
    int i = 1;
    int j = 1;
    int k = 0;
    int l =0;
    bool flag1 = false, flag2 = false;
    bool sign = false;
    while (a[k] == '0')
        k++;
    while (b[l] == '0')
        l++;
    if (a[k ] == '-')
    {
        flag1 = true;
        k++;
       
    }
    if (b[l] == '-')
    {
        flag2 = true;
        l++;
        
    }
    if ((flag1 && !flag2) || (!flag1 && flag2))
        sign = true;

    Stack<int> result;
    int reminder = 0;
    int sumDigit = 0;
    while (i <= a.size() - k && j <= b.size() -l)
    {

        sumDigit = (a[a.size() - i] - 48) + (b[b.size() - j] - 48) + reminder;
        if (sumDigit > 9)
        {
            reminder = 1;
        }
        else
        {
            reminder = 0;
        }
        result.push(sumDigit % 10);
        i++;
        j++;
    }
    if (i <= a.size() -k)
    {
        while (i <= a.size() -k)
        {
            sumDigit = (a[a.size() - i] - 48) + reminder;
            if (sumDigit > 9)
            {
                reminder = 1;
            }
            else
            {
                reminder = 0;
            }
            result.push(sumDigit % 10);
            i++;
        }
    }
    else
    {
        while (j <= b.size() -l)
        {
            sumDigit = (b[b.size() - j] - 48) + reminder;
            if (sumDigit > 9)
            {
                reminder = 1;
            }
            else
            {
                reminder = 0;
            }
            result.push(sumDigit % 10);
            j++;
        }
    }
    if (reminder == 1)
        result.push(reminder);

    cout << "Output: ";
    if (flag1 && flag2)
        cout << "-";
    while (!result.isEmpty())
        cout << result.pop();

    return 0;
}
bool check(string str)
{
    Stack<char> arr;
    for (int i = 0; i < str.size(); i++)
    {
        if (str[i] == '(' || str[i] == '{' || str[i] == '[')
            arr.push(str[i]);
        else if (str[i] == ')')
        {
            if (arr.pop() != '(')
                return false;
        }
        else if (str[i] == '}')
        {
            if (arr.pop() != '{')
                return false;
        }
        else if (str[i] == ']')
        {
            if (arr.pop() != '[')
                return false;
        }
    }
    if (!arr.isEmpty())
        return false;
    return true;
}
