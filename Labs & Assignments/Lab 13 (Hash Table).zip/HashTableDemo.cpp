#include "HashTable.cpp"

int main()
{
    string name;
    cout << "Enter the size of the table: ";
    int size;
    cin >> size;
    while (size <= 0 || size > INT16_MAX)
    {
        cout << "ERROR! Please enter a valid size: ";
        cin >> size;
    }
    cout << endl
         << endl;
    HashTable table(size);
    bool flag;
    while (true)
    {
        cout << "1. Insert a name\n2. Search for a name\n3. Remove a name\n4. Display the table\n";
        cout << "5. Display the load factor of the table\n6. Exit\n\nEnter your choice: ";
        char choice;
        cin >> choice;
        while (choice < '1' || choice > '6')
        {
            cout << "ERROR!! Please enter a valid choice: ";
            cin >> choice;
        }
        cin.ignore();
        if (choice == '1')
        {
            cout << "Enter the name to insert: ";
            getline(cin, name);
            flag = table.insert(name);
            if (flag)
                cout << name << " inserted successfully\n";
            else
                cout << name << " cannot be inserted successfully\n";
        }
        else if (choice == '2')
        {
            cout << "Enter the name to search for: ";
            getline(cin, name);
            flag = table.search(name);
            if (flag)
                cout << name << " is found in the table" << endl;
            else
                cout << name << " is not found in the table" << endl;
        }
        else if (choice == '3')
        {
            cout << "Enter the name to remove: ";
            getline(cin, name);
            flag = table.remove(name);
            if (flag)
                cout << name << " is removed from the table" << endl;
            else
                cout << name << " is not found/removed in/from the table" << endl;
        }
        else if (choice == '4')
        {
            table.display();
        }
        else if (choice == '5')
        {
            cout << "Load factor: " << table.loadFactor() << endl;
        }
        else
            exit(0);
        cout << "\n----------------------------------------------------------------";
        cout << "\nPress any key to continue..." << endl;
        system("pause>0");
        system("cls");
    }
    return 0;
}