#ifndef HASHTABLE_H
#define HASHTABLE_H
#include <iostream>
using namespace std;
class HashTable
{
    string *table;
    int size;
    int curSize;

public:
    HashTable(int);
    ~HashTable();
    bool isEmpty();
    bool isFull();
    double loadFactor();
    int hashFunction(string);
    bool insert(string);
    bool remove(string);
    bool search(string);
    void display();
};
#endif