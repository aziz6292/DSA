#include "HashTable.h"
HashTable::HashTable(int s) : size(s), curSize(0), table(NULL)
{
    table = new string[size]{};
}
HashTable::~HashTable()
{
    if (table)
    {
        delete[] table;
        table = NULL;
    }
}
bool HashTable::isEmpty()
{
    return curSize == 0;
}
bool HashTable::isFull()
{
    return curSize == size;
}
double HashTable::loadFactor()
{
    return (curSize * 1.0) / size;
}
int HashTable::hashFunction(string name)
{
    int sum = 0;
    int i = 0;
    while (i < name.size())
    {
        sum = sum + name[i];
        i++;
    }
    return sum % size;
}
bool HashTable::insert(string name)
{
    if (isFull())
        return false;
    int index = hashFunction(name);
    while (!(table[index] == "" || table[index] == "EMPTY'"))
    {
        index = (index + 1) % size;
    }
    table[index] = name;
    curSize++;
    return true;
}
bool HashTable::search(string name)
{
    int index = hashFunction(name);
    int start = index;
    while (table[index] != name)
    {
        if (table[index] == "")
            return false;
        index = (index + 1) % size;
        if (index == start)
            return false;
    }
    return true;
}
bool HashTable::remove(string name)
{
    int index = hashFunction(name);
    int start = index;
    while (table[index] != name)
    {
        if (index == size || table[index] == "")
            return false;
        index = (index + 1) % size;
        if (index == start)
            return false;
    }
    table[index] = "EMPTY'";
    curSize--;
    return true;
}
void HashTable::display()
{
    for (int i = 0; i < size; i++)
        if (table[i] == "EMPTY'" || table[i] == "")
            cout << "EMPTY\t";
        else
            cout << table[i] << "\t";
    cout << endl;
}

