//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#include "AVLNode.h"
#include <iomanip>

template <typename T>
void AVLNode<T>::AVLNodeCreation(BSTNode<T> *node, BSTNode<T> *org)
{
    if (node)
    {
        if (node->data > org->data)
            org = org->right = new BSTNode<T>(node->data);
        if (node->data < org->data)
            org = org->left = new BSTNode<T>(node->data);
        AVLNodeCreation(node->left, org);
        AVLNodeCreation(node->right, org);
    }
}
template <typename T>
void AVLNode<T>::AVLNodeDeletion(BSTNode<T> *node)
{

    if (node)
    {
        AVLNodeDeletion(node->right);
        AVLNodeDeletion(node->left);
        delete node;
        node = NULL;
    }
}
template <typename T>
void AVLNode<T>::modifyTree(BSTNode<T> *A, BSTNode<T> *parA)
{
    BSTNode<T> *B = NULL, *C = NULL;
    int factor = getBalanceFactor(A);
    if (factor < 0)
        B = A->right;
    else
        B = A->left;
    factor = getBalanceFactor(B);
    if (factor < 0)
        C = B->right;
    else
        C = B->left;

    if (parA)
        cout << "parent of A = " << parA->data << " ";
    cout << "A = " << A->data << ", B = " << B->data << ", C = " << C->data << endl;
    if (A->left == B && B->left == C) // LL, so right rotate at A
    {
        cout << "LL call\n";
        A->left = B->right;
        B->right = A;
        if (parA)
        {
            if (A == parA->left)
                parA->left = B;
            else
                parA->right = B;
        }
        else
            root = B;
        A->height = getHeight(A);
        C->height = getHeight(C);
        B->height = getHeight(B);
    }
    else if (A->right == B && B->right == C) // RR, so left rotate at A
    {
        cout << "RR call\n";
        A->right = B->left;
        B->left = A;
        if (parA)
        {
            if (A == parA->left)
                parA->left = B;
            else
                parA->right = B;
        }
        else
            root = B;
        A->height = getHeight(A);
        C->height = getHeight(C);
        B->height = getHeight(B);
    }
    else if (A->left == B && B->right == C) // LR, left rotate at B and then right rotate at A
    {
        cout << "LR call\n";
        B->right = C->left;
        C->left = B;
        A->left = C->right;
        C->right = A;
        if (parA)
        {
            if (A == parA->left)
                parA->left = C;
            else
                parA->right = C;
        }
        else
            root = C;
        A->height = getHeight(A);
        B->height = getHeight(B);
        C->height = getHeight(C);
    }
    else if (A->right == B && B->left == C) // RL, right rotate at B and then left rotate at A
    {
        cout << "RL call\n";
        B->left = C->right;
        C->right = B;
        A->right = C->left;
        C->left = A;
        if (parA)
        {
            if (A == parA->left)
                parA->left = C;
            else
                parA->right = C;
        }
        else
            root = C;
        A->height = getHeight(A);
        B->height = getHeight(B);
        C->height = getHeight(C);
    }
}
// copy constructor
template <typename T>
AVLNode<T>::AVLNode(const AVLNode<T> &obj)
{
    BSTNode<T> *cur = obj.root;
    if (!cur)
        root = NULL;
    else
    {
        root = new BSTNode<T>(obj.root->data);
        AVLNodeCreation(obj.root, root);
    }
}
// assignment operator
template <typename T>
const AVLNode<T> &AVLNode<T>::operator=(const AVLNode<T> &obj)
{
    if (this == &obj)
        return *this;
    if (root)
        this->~AVLNode();
    if (!obj.root)
        root = NULL;
    else
    {
        root = new BSTNode<T>(obj.root->data);
        AVLNodeCreation(obj.root, root);
    }
    return *this;
}
template <typename T>
AVLNode<T>::~AVLNode()
{
    AVLNodeDeletion(root);
}
// function
template <typename T>
AVLNode<T> *AVLNode<T>::search(const T &key)
{
    BSTNode<T> *cur = root;
    while (cur)
    {
        if (cur->data == key)
            return this;
        if (cur->data > key)
            cur = cur->left;
        else
            cur = cur->right;
    }
    return NULL;
}
template <typename T>
void AVLNode<T>::insert(T key)
{
    BSTNode<T> *cur = root, *pre = NULL;
    while (cur)
    {
        pre = cur;
        if (cur->data == key)
            return;
        if (cur->data > key)
            cur = cur->left;
        else
            cur = cur->right;
    }
    if (!pre)
        cur = root = new BSTNode<T>(key);
    else
    {
        if (pre->data < key)
            cur = pre->right = new BSTNode<T>(key);
        else
            cur = pre->left = new BSTNode<T>(key);
    }
    modifyHeights(root, key);
}

template <typename T>
void AVLNode<T>::deleteNode(T key)
{
    BSTNode<T> *cur = root, *pre = NULL;
    while (cur && cur->data != key)
    {
        pre = cur;
        if (cur->data > key)
            cur = cur->left;
        else
            cur = cur->right;
    }
    if (!cur)
    {
        cout << "value " << key << " is not found\n";
        return;
    }
    // case degree 2
    if (cur->left && cur->right)
    {
        BSTNode<T> *r = cur->right, *pr = cur;
        while (r->left)
        {
            pr = r;
            r = r->left;
        }
        cur->data = r->data;
        cur = r;
        pre = pr;
    }
    // case degree 1
    // case degree 0
    BSTNode<T> *temp = NULL;
    if (cur->right)
        temp = cur->right;
    else
        temp = cur->left;
    if (!pre)
        root = temp;
    else
    {
        if (cur == pre->right)
            pre->right = temp;
        else
            pre->left = temp;
    }
    delete cur;
    cur = NULL;
    cout << "value  " << key << " is successfully deleted" << endl;
    if (pre)
        modifyHeights(root, pre->data);
}

template <typename T>
int AVLNode<T>::getBalanceFactor(BSTNode<T> *node)
{
    int leftHeight = 0, rightHeight = 0;

    if (node && node->left)
        leftHeight = getHeight(node->left);
    if (node && node->right)
        rightHeight = getHeight(node->right);
    return leftHeight - rightHeight;
}

template <typename T>
void AVLNode<T>::modifyHeights(BSTNode<T> *node, T key)
{
    if (!node)
        return;
    else
    {
        int factor = 0;
        if (node->data != key)
        {
            if (node->data < key)
                modifyHeights(node->right, key);
            else
                modifyHeights(node->left, key);
            node->height = getHeight(node);
            factor = getBalanceFactor(node);
            if (factor < -1 || factor > 1)
                modifyTree(node, getParent(node));
        }
        else
        {
            node->height = getHeight(node);
            factor = getBalanceFactor(node);
            if (factor < -1 || factor > 1)
                modifyTree(node, getParent(node));
        }
    }
}
template <typename T>
void AVLNode<T>::printNodes(BSTNode<T> *node)
{
    if (node)
    {
        queue<BSTNode<T> *> treeQueue;
        treeQueue.push(node);
        while (!treeQueue.empty())
        {
            node = treeQueue.front();
            cout << node->data << " ";
            treeQueue.pop();
            if (node->left)
                treeQueue.push(node->left);
            if (node->right)
                treeQueue.push(node->right);
        }
    }
}
template <typename T>
BSTNode<T> *AVLNode<T>::getParent(BSTNode<T> *node)
{
    BSTNode<T> *parent = NULL;
    BSTNode<T> *cur = root;
    while (cur != node)
    {
        parent = cur;
        if (cur->data > node->data)
            cur = cur->left;
        else
            cur = cur->right;
    }
    return parent;
}
template <typename T>
void AVLNode<T>::printTree()
{
    if (root)
    {
        if (isBST(root))
            cout << "Tree is A valid BST Tree" << endl;
        else
            cout << "Tree is not A valid BST Tree" << endl;
        int hight = getHeight(root);
        queue<BSTNode<T> *> treeQueue;
        treeQueue.push(root);
        BSTNode<T> *node = NULL;
        int level = 1;
        for (int i = 0; i < hight; i++)
        {
            int j = 0;
            while (j < hight - i)
            {
                cout << setw(6) << "";
                j++;
            }
            j = 0;
            while (j < level)
            {
                if (!treeQueue.empty())
                {
                    node = treeQueue.front();
                    treeQueue.pop();
                }
                if (node)
                {
                    if (node->left)
                        treeQueue.push(node->left);
                    else
                        treeQueue.push(NULL);
                    if (node->right)
                        treeQueue.push(node->right);
                    else
                        treeQueue.push(NULL);
                    cout << setw(6) << node->data;
                }
                else
                    cout << setw(6) << "";
                j++;
                if (j * 2 == level)
                    cout << setw(3 * (hight - i)) << "";
            }
            cout << endl
                 << endl;
            level = level * 2;
        }
        cout << "--------------------------------";
    }
}
template <typename T>
int AVLNode<T>::getHeight(BSTNode<T> *node)
{
    if (!node)
        return 0;
    if (!node->right && !node->left)
        return 1;
    if (!node->right && node->left)
        return node->left->height + 1;
    if (node->right && !node->left)
        return node->right->height + 1;
    if (node->right && node->left)
        return node->right->height > node->left->height ? node->right->height + 1 : node->left->height + 1;
}
template <typename T>
bool AVLNode<T>::isBST(BSTNode<T> *node)
{
    if (node)
    {
        if ((node->left && node->data < node->left->data) || (node->right && node->data > node->right->data))
            return false;
        bool flag1 = false;
        bool flag2 = false;
        flag1 = isBST(node->right);
        if (!flag1)
            return false;
        flag2 = isBST(node->left);
        if (flag1 && flag2)
            return true;
        else
            return false;
    }
    else
        return true;
}
