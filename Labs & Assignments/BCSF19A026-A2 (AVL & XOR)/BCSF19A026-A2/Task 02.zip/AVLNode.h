//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#ifndef AVL_H
#define AVL_H
#include <iostream>
#include <queue>
using namespace std;

template <typename T>
class AVLNode;
template <typename T>
class BSTNode
{
    friend class AVLNode<T>;
    T data;
    int height;
    BSTNode<T> *right, *left;

public:
    BSTNode() : height(1), data({}), right(NULL), left(NULL) {}
    BSTNode(T val) : height(1), data(val), right(NULL), left(NULL) {}
    void printNode()
    {
        cout << "Node Data: " << data << endl;
    }
};

template <typename T>
class AVLNode
{
    BSTNode<T> *root;

    // private functions
    void AVLNodeCreation(BSTNode<T> *, BSTNode<T> *);
    void AVLNodeDeletion(BSTNode<T> *);
    void modifyTree(BSTNode<T> *, BSTNode<T> *);
    void modifyHeights(BSTNode<T> *, T);

public:
    AVLNode() : root(NULL) {}
    AVLNode(const AVLNode &);
    const AVLNode &operator=(const AVLNode &);
    ~AVLNode();
    // function
    AVLNode<T> *search(const T &);
    void insert(T);
    void deleteNode(T);
    bool isBST(BSTNode<T> *);
    int getBalanceFactor(BSTNode<T> *);
    void printNodes(BSTNode<T> *);
    BSTNode<T> *getParent(BSTNode<T> *);
    void printTree();
    int getHeight(BSTNode<T> *);
};
#endif