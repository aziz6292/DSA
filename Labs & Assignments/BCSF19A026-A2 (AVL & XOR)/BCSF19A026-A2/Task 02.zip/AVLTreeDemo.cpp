//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************

#include "AVLNode.cpp"

void validate(int &);
int main()
{
    AVLNode<int> tree;
    AVLNode<int> tree1;
    cout << "****************************************************************\n";
    cout << "                       **~ WELCOME ~**\n";
    cout << "****************************************************************\n";
    while (true)
    {
        cout << "\nPlease select from the list below" << endl;
        cout << "(a)\tInsert a new node\n(b)\tSearch a node\n";
        cout << "(c)\tDelete a node\n(d)\tPrint the tree\nYour choice: ";
        char choice;
        while (cin >> choice && (choice < 'a' || choice > 'd'))
            cout << "Invalid Selection: " << choice << endl
                 << "Please select a choice between a-d: ";

        if (choice == 'a')
        {
            cout << "Enter value to insert (integer value): ";
            int value;
            cin >> value;
            validate(value);
            tree.insert(value);
            cout << endl
                 << "Value -> " << value << " is Either already present or inserted successfully!\n";
        }
        else if (choice == 'b')
        {
            cout << "Enter value to Search (integer value): ";
            int value;
            cin >> value;
            validate(value);
            AVLNode<int> *subTree = tree.search(value);
            if (subTree)
            {
                cout << "value " << value << " is found in the tree below " << endl;
                subTree->printTree();
            }
            else
                cout << "value " << value << " is not found\n";
        }
        else if (choice == 'c')
        {
            cout << "Enter value to delete (integer value): ";
            int value;
            cin >> value;
            validate(value);
            tree.deleteNode(value);
            cout << "Value deleted successfully!\n";
        }
        else
            tree.printTree();
        cout << "\n________________________________________________________________";
        cout << "\nPress 'Q' to exit OR any key to continue..." << endl;
        cin.ignore();
        cin.get(choice);
        if (choice == 'Q' || choice == 'q')
            exit(0);
        system("cls");
    }
    return 0;
}
void validate(int &value)
{
    while (value < INT16_MIN || value > INT16_MAX)
    {
        cout << "Value must be between " << INT16_MIN << " and " << INT16_MAX << endl;
        cout << "Re-enter the value: ";
        cin >> value;
    }
}