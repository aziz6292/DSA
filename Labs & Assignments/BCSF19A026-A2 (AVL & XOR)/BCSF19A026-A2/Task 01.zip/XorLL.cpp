//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#include "XorLL.h"
template <typename T>
XorLL<T>::XorLL(const XorLL<T> &obj) : XorLL()
{
    Node<T> *cur = obj.head;
    Node<T> *prev = NULL;
    Node<T> *temp = NULL;
    while (prev != obj.tail)
    {
        insertAtTail(cur->data);
        temp = getXor(prev, cur->npx);
        prev = cur;
        cur = temp;
    }
}
template <typename T>
const XorLL<T> &XorLL<T>::operator=(const XorLL<T> &obj)
{
    if (this == &obj)
        return *this;
    if (head)
        this->~XorLL();
    Node<T> *cur = obj.head;
    Node<T> *prev = NULL;
    Node<T> *temp = NULL;
    while (prev != obj.tail)
    {
        insertAtTail(cur->data);
        temp = getXor(prev, cur->npx);
        prev = cur;
        cur = temp;
    }
    return *this;
}
template <typename T>
XorLL<T>::~XorLL()
{
    if (!isEmpty())
    {
        Node<T> *cur = head->npx;
        Node<T> *prev = head;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            temp = getXor(prev, cur->npx);
            if (prev)
            {
                delete prev;
            }
            prev = cur;
            cur = temp;
        }
        if (head)
        {
            delete head;
            head = NULL;
        }
        if (tail)
        {
            delete tail;
            tail = NULL;
        }
        head = tail = NULL;
    }
}
template <typename T>
Node<T> *XorLL<T>::getXor(Node<T> *prev, Node<T> *next)
{
    return (Node<T> *)((uintptr_t)(prev) ^ (uintptr_t)(next));
}
template <typename T>
bool XorLL<T>::isEmpty()
{
    if (head == NULL)
        return true;
    return false;
}
template <typename T>
void XorLL<T>::insertAtHead(T val)
{
    if (!isEmpty())
    {
        if (head->npx == NULL)
        {
            tail = head;
            head = new Node<T>(val);
            tail->npx = head;
            head->npx = tail;
        }
        else
        {
            Node<T> *temp = head;
            head = new Node<T>(val);
            temp->npx = getXor(head, temp->npx);
            head->npx = temp;
        }
    }
    else
    {
        head = new Node<T>(val);
        tail = head;
        tail->npx = NULL;
        head->npx = NULL;
    }
}
template <typename T>
void XorLL<T>::insertAfter(T key, T val)
{
    if (isEmpty())
        insertAtHead(val);
    else if (tail->data == key)
        insertAtTail(val);
    else
    {
        Node<T> *cur = head;
        Node<T> *prev = NULL;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            if (cur->data == key)
            {
                Node<T> *newNode = new Node<T>(val);
                temp = getXor(prev, cur->npx);
                newNode->npx = getXor(cur, temp);
                cur->npx = getXor(newNode, prev);
                temp->npx = getXor(getXor(temp->npx, cur), newNode);
                return;
            }
            temp = getXor(prev, cur->npx);
            prev = cur;
            cur = temp;
        }
        insertAtHead(val);
    }
}
template <typename T>
void XorLL<T>::insertAtTail(T val)
{
    if (isEmpty())
    {
        head = new Node<T>(val);
        tail = head;
        head->npx = tail->npx = NULL;
    }
    else
    {
        Node<T> *cur = tail;
        Node<T> *prev = tail->npx;
        Node<T> *newNode = new Node<T>(val);
        newNode->npx = getXor(tail, NULL);
        tail = newNode;
        cur->npx = getXor(prev, newNode);
    }
}

template <typename T>
void XorLL<T>::removeAtTail()
{
    if (isEmpty())
    {
        cout << "List is empty!" << endl;
        return;
    }
    if (head == tail)
    {
        cout << "Successfully deleted value " << head->data << " of list" << endl;
        this->~XorLL();
        return;
    }
    else
    {
        cout << "Successfully deleted value " << tail->data << " of list" << endl;
        Node<T> *cur = tail;
        Node<T> *prev = tail->npx;
        Node<T> *temp = getXor(prev->npx, cur);
        tail = prev;
        delete cur;
        cur = NULL;
        tail->npx = getXor(temp, cur);
        return;
    }
}
template <typename T>
void XorLL<T>::removeAtHead()
{
    if (isEmpty())
    {
        cout << "List is empty!" << endl;
        return;
    }
    if (head == tail)
    {
        cout << "Successfully deleted value " << head->data << " of list" << endl;
        this->~XorLL();
        return;
    }
    else
    {
        cout << "Successfully deleted value " << head->data << " of list" << endl;
        Node<T> *prev = head;
        Node<T> *cur = head->npx;
        Node<T> *temp = getXor(cur->npx, prev);
        head = cur;
        delete prev;
        prev = NULL;
        head->npx = getXor(temp, prev);
    }
}

template <typename T>
void XorLL<T>::deleteBefore(T val)
{
    if (isEmpty())
    {
        cout << "List is empty!" << endl;
        return;
    }
    else if (val == head->data)
    {
        cout << val << " found at head!!\nno node found before\n";
        return;
    }
    else if ( val == head->npx->data)
    {
        removeAtHead();
        return;
    }
    else
    {
        Node<T> *cur = head;
        Node<T> *prev = NULL;
        Node<T> *temp = NULL;
        while (prev != tail)
        {
            if (cur->data == val)
            {
                temp = getXor(cur, prev->npx);
                temp->npx = getXor(getXor(temp->npx, prev), cur);
                cur->npx = getXor(getXor(cur->npx, prev), temp);
                delete prev;
                prev = NULL;
                cout << "Successfully deleted before " << val << endl;
                return;
            }
            temp = getXor(prev, cur->npx);
            prev = cur;
            cur = temp;
        }
    }
    cout << val << " not found in the list " << endl;
}

template <typename T>
void XorLL<T>::printList() const
{
    Node<T> *cur = head,
            *prev = NULL, *temp = NULL;
    while (prev != tail)
    {
        cout << cur->data << " -> ";
        temp = (Node<T> *)((uintptr_t)(prev) ^ (uintptr_t)(cur->npx));
        prev = cur;
        cur = temp;
    }
    cout << endl;
}
