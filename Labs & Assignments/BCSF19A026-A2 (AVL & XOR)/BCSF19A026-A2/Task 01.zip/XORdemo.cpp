//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#include "XorLL.cpp"

int main()
{
    XorLL<int> list;
    cout << "*****************************" << endl;
    cout << "********  WELCOME  **********" << endl;
    cout << "*****************************" << endl;
    int val, key;
    while (true)
    {
        cout << "Please select from the following list\n";
        cout << "1.\tInsert At Head\n2.\tInsert At Tail\n3.\tInsert After\n4.\tDelete Before\n";
        cout << "5.\tRemove At Head\n6.\tRemove At Tail\n7.\tPrint List\n0.\tExit\nYour Selection: ";
        char choice;
        while (cin >> choice && (choice < '0' || choice > '7'))
            cout << "Re-enter the valid choice 0-7: ";
        if (choice == '0')
            exit(0);
        else if (choice == '1')
        {
            cout << "Enter value: ";
            while (cin >> val && (val < INT16_MIN || val > INT16_MAX))
                cout << "Re-enter value: ";
            list.insertAtHead(val);
            cout << val << " Successfully insert into the list" << endl;
        }
        else if (choice == '2')
        {
            cout << "Enter value: ";
            while (cin >> val && (val < INT16_MIN || val > INT16_MAX))
                cout << "Re-enter value: ";
            list.insertAtTail(val);
            cout << val << " Successfully insert into the list" << endl;
        }
        else if (choice == '3')
        {
            cout << "Enter value to insert: ";
            while (cin >> val && (val < INT16_MIN || val > INT16_MAX))
                cout << "Re-enter value: ";
            cout << "Enter key to insert after: ";
            while (cin >> key && (key < INT16_MIN || key > INT16_MAX))
                cout << "Re-enter key value: ";
            list.insertAfter(key, val);
            cout << val << " Successfully insert into the list" << endl;
        }
        else if (choice == '4')
        {
            cout << "Enter key to delete Before: ";
            while (cin >> key && (key < INT16_MIN || key > INT16_MAX))
                cout << "Re-enter key value: ";
            list.deleteBefore(key);
        }
        else if (choice == '5')
            list.removeAtHead();
        else if (choice == '6')
            list.removeAtTail();
        else
            list.printList();
        cout << endl
             << endl
             << "Press any key to continue..." << endl;
        system("pause>0");
        system("cls");
    }

    return 0;
}