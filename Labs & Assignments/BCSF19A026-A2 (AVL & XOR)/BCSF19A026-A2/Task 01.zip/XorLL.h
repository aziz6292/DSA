//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#ifndef XORLL_H
#define XORLL_H
#include <iostream>
using namespace std;
template <typename T>
struct Node
{
    T data;
    Node<T> *npx;
    Node() : data({}), npx(NULL) {}
    Node(T val) : data(val), npx(NULL) {}
};
template <typename T>
class XorLL
{
    Node<T> *head;
    Node<T> *tail;

public:
    XorLL() : head(NULL), tail(NULL) {}
    XorLL(const XorLL<T> &);
    const XorLL<T> &operator=(const XorLL<T> &);
    ~XorLL();
    Node<T> *getXor(Node<T> *, Node<T> *);
    bool isEmpty();
    void insertAtHead(T);
    void insertAtTail(T);
    void insertAfter(T, T);
    void deleteBefore(T);
    void removeAtTail();
    void removeAtHead();
    void printList() const;
};
#endif