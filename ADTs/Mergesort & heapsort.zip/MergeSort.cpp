// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#include <iostream>
using namespace std;
template <typename T>
void merge(T *, int, int, int, int);
template <typename T>
void mergeSort(T *, int);
template <typename T>
void mergeSort(T *, int, int);
template <typename T>
void display(T *, int);

int main()
{
    int arr[11] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0};
    mergeSort(arr, 11);
    display(arr, 11);
    return 0;
}



template <typename T>
void mergeSort(T *arr, int size)
{
    mergeSort(arr, 0, size - 1);
}
template <typename T>
void display(T *arr, int size)
{
    for (int i = 0; i < size; i++)
        cout << arr[i] << " ";
    cout << endl;
}
template <typename T>
void merge(T *arr, int l1, int l2, int r1, int r2)
{
    int S = (r2 - l1) + 1;
    T *temp = new T[S];
    int i = l1, j = r1, k = 0;
    while (i <= l2 && j <= r2)
        if (arr[i] <= arr[j])
            temp[k++] = arr[i++];
        else
            temp[k++] = arr[j++];
    while (i <= l2)
        temp[k++] = arr[i++];
    while (j <= r2)
        temp[k++] = arr[j++];
    k = 0, i = l1;
    while (i <= r2 || k < S)
        arr[i++] = temp[k++];
    delete[] temp;
    temp = NULL;
}
template <typename T>
void mergeSort(T *arr, int start, int end)
{
    if (start < end)
    {
        int mid = (start + end) / 2;
        mergeSort(arr, start, mid);
        mergeSort(arr, mid + 1, end);
        merge(arr, start, mid, mid + 1, end);
    }
}