// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop

#include "CDLL.cpp"
int main()
{
    CDLL<int> list;
    for (int i = 10; i> 0; i--)
    list.insertAtTail(i);
    cout <<list.getNode(5)->data<<endl;
    list.print();
    list.sort();
    list.print();
    return 0;
}