//Abdul Aziz
//BCSF19A026
//CS Afternoon Add/Drop
#ifndef C_DLL
#define C_DLL
#include <iostream>
using namespace	std;
template <typename T>
class Node
{
public:
	T data;
	Node<T> *prev;
	Node<T> *next;

public:
	Node() : prev(NULL), next(NULL) {}
	Node(T value) : data(value), prev(NULL), next(NULL) {}
};
template <typename T>
class CDLL
{
private:
	Node<T> head;

public:
	CDLL();
	CDLL(const CDLL<T> &);
	~CDLL();
	const CDLL<T> &operator=(const CDLL<T> &);
	Node<T> *search(T key);
	bool isEmpty();
	void insertAfter(T , T );
	void insertBefore(T , T );
	bool deleteAtTail();
	bool deleteAtHead();
	bool deleteAfter(T );
	bool deleteBefore(T );
	void insertAtHead(T);
	void insertAtTail(T);
	void print() const;
	void sortedInsert(T);
	bool sortedDelete(T);
	void sort();
	bool deleteAt(T);
	int getLength() const;
	Node <T> * getNode (int);
};

#endif // !CLL
