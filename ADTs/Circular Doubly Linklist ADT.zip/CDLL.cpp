// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#include <iostream>
using namespace std;

#include "CDLL.h"
template <typename T>
CDLL<T>::CDLL()
{
	head.next = &head;
	head.prev = &head;
}
template <typename T>
CDLL<T>::CDLL(const CDLL<T> &org)
{
	Node<T> *orgIterator = org.head.next;
	head.next = &head;
	head.prev = &head;
	while (orgIterator != &(org.head))
	{
		insertAtEnd(orgIterator->data);
		orgIterator = orgIterator->next;
	}
}
template <typename T>
const CDLL<T> &CDLL<T>::operator=(const CDLL<T> &rhs)
{
	if (&head != &(rhs.head))
	{
		if (head.next != &head)
			this->~CDLL();
		Node<T> *rhsIterator = rhs.head.next;
		head.next = &head;
		head.prev = &head;
		while (rhsIterator != &(rhs.head))
		{
			insertAtEnd(rhsIterator->data);
			rhsIterator = rhsIterator->next;
		}
	}
	return *this;
}
template <typename T>
CDLL<T>::~CDLL()
{
	Node<T> *temp = head.next;
	while (temp != &head)
	{
		head.next = temp->next;
		if (temp != NULL)
		{
			delete temp;
			temp = NULL;
		}
		temp = head.next;
	}
	head.next = &head;
	head.prev = &head;
}
template <typename T>
Node<T> *CDLL<T>::search(T key)
{
	if (!isEmpty())
	{
		Node<T> *cur = head.next;
		while (cur != &head)
		{
			if (cur->data == key)
				return cur;
			cur = cur->next;
		}
	}
	return &head;
}
template <typename T>
bool CDLL<T>::isEmpty()
{
	if (head.next == &head)
		return true;
	return false;
}
template <typename T>
void CDLL<T>::insertAtHead(T val)
{
	Node<T> *temp = new Node<T>(val);
	temp->next = head.next;
	temp->prev = &head;
	head.next->prev = temp;
	head.next = temp;
}
template <typename T>
void CDLL<T>::insertAtTail(T val)
{
	Node<T> *temp = new Node<T>(val);
	temp->next = &head;
	temp->prev = head.prev;
	head.prev->next = temp;
	head.prev = temp;
}
template <typename T>
void CDLL<T>::sortedInsert(T val)
{
	Node<T> *temp = new Node<T>(val);
	Node<T> *curr = head.next;
	while (curr != &head && val > curr->data)
	{
		curr = curr->next;
	}
	temp->next = curr;
	temp->prev = curr->prev;
	curr->prev->next = temp;
	curr->prev = temp;
}
template <typename T>
void CDLL<T>::insertAfter(T key, T value)
{
	Node<T> *cur = search(key);
	if (cur == &head)
		insertAtHead(value);
	else
	{
		Node<T> *temp = new Node<T>(value);
		temp->next = cur->next;
		temp->prev = cur;
		cur->next->prev = temp;
		cur->next = temp;
	}
}
template <typename T>
void CDLL<T>::insertBefore(T key, T value)
{
	if (!isEmpty() && head.next->data != key)
	{
		Node<T> *cur = head.next->next;
		Node<T> *pre = head.next;
		while (cur != &head)
		{
			if (cur->data == key)
			{
				Node<T> *temp = new Node<T>(value);
				pre->next = temp;
				temp->prev = pre;
				cur->prev = temp;
				temp->next = cur;
				return;
			}
			pre = cur;
			cur = cur->next;
		}
		insertAtHead(value);
	}
	else
		insertAtHead(value);
}
template <typename T>
bool CDLL<T>::deleteAfter(T key)
{
	Node<T> *cur = search(key);
	if (cur != &head)
	{
		if (cur == head.prev)
			deleteAtHead();

		else if (cur == head.prev->prev)
			deleteAtTail();
		else
		{
			Node<T> *temp = cur->next;
			cur->next->next->prev = cur;
			cur->next = cur->next->next;
			delete temp;
			temp = NULL;
		}
		return true;
	}
	return false;
}
template <typename T>
bool CDLL<T>::deleteAtTail()
{
	if (!isEmpty())
	{
		Node<T> *cur = head.prev;
		if (cur->prev == &head)
		{
			delete cur;
			cur = NULL;
			head.next = &head;
			head.prev = &head;
			return true;
		}
		else
		{
			Node<T> *temp = head.prev->prev;
			head.prev->prev->next = &head;
			head.prev = temp;
			delete cur;
			cur = NULL;
			return true;
		}
	}
	return false;
}
template <typename T>
bool CDLL<T>::deleteAtHead()
{
	if (!isEmpty())
	{
		Node<T> *cur = head.next;
		if (cur->next == &head)
		{
			delete cur;
			cur = NULL;
			head.next = &head;
			head.prev = &head;
			return true;
		}
		else
		{
			Node<T> *temp = head.next->next;
			head.next->next->prev = &head;
			head.next = temp;
			delete cur;
			cur = NULL;
			return true;
		}
	}
	return false;
}
template <typename T>
bool CDLL<T>::deleteBefore(T key)
{
	if (!isEmpty())
	{
		Node<T> *pre = head.next;
		if (pre->data == key)
		{
			deleteAtTail();
			return true;
		}
		if (head.next->next != &head)
		{
			Node<T> *cur = head.next->next;
			if (cur->data == key)
			{

				deleteAtHead();
				return true;
			}
			else
			{
				while (cur->next != &head)
				{
					if (cur->next->data == key)
					{
						pre->next = cur->next;
						cur->next->prev = pre;
						delete cur;
						cur = NULL;
						return true;
					}
					pre = pre->next;
					cur = cur->next;
				}
			}
		}
	}
	return false;
}
template <typename T>
bool CDLL<T>::sortedDelete(T val)
{
	Node<T> *curr = head.next;
	while (curr != &head && val > curr->data)
	{
		curr = curr->next;
	}
	if (curr != &head && curr->data == val)
	{
		curr->next->prev = curr->prev;
		curr->prev->next = curr->next;

		delete curr;
		curr = NULL;
		return true;
	}
	else
		return false;
}
template <typename T>
bool CDLL<T>::deleteAt(T val)
{
	Node<T> *curr = head.next;
	while (curr != &head && val != curr->data)
	{
		curr = curr->next;
	}
	if (curr != &head && curr->data == val)
	{
		curr->next->prev = curr->prev;
		curr->prev->next = curr->next;
		delete curr;
		curr = NULL;
		return true;
	}
	else
		return false;
}
template <typename T>
void CDLL<T>::print() const
{
	Node<T> *temp = head.next;
	while (temp != &head)
	{
		cout << temp->data << " ";
		temp = temp->next;
	}
	cout << endl;
}
template <typename T>
int CDLL<T>::getLength() const
{
	Node<T> *cur = head.next;
	int len = 0;
	for (; cur != &head; cur = cur->next)
		len++;
	return len;
}
template <typename T>
void CDLL<T>::sort()
{
	int len = getLength();
	bool noSwap = true;
	int j = 0;
	Node<T> *cur = NULL;
	while (noSwap)
	{
		noSwap = false;
		cur = head.next;
		for (int i = 0; i < len - j; i++, cur = cur->next)
			if (cur->data > cur->next->data)
			{
				swap(cur->data, cur->next->data);
				noSwap = true;
			}
		j++;
	}
}
template <typename T>
Node<T> *CDLL<T>::getNode(int index)
{
	if (index <= 0 || index >= getLength())
	{
		cout << "Invalid index: " << index << endl;
		return NULL;
	}
	else
	{
		Node<T> *cur = head.next;
		index--;
		while (index)
		{
			cur = cur->next;
			index--;
		}
		return cur;
	}
}