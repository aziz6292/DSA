//Abdul Aziz
//BCSF19A026
//CS Afternoon Add/drop

#include "Queue.h"
template <typename T>
Queue<T>::Queue()  //default constructor
{
	front = 0;
	rear = 0;
	size = 0;
	capacity = 0;
	data = NULL;
	pArr = NULL;
}
 
template <typename T>
Queue<T>::~Queue()  //destructor
{
	if (data)
	{
		delete[] pArr;
		pArr = NULL;
		delete[] data;
		data = NULL;
		rear = 0;
		front = 0;
		capacity = 0;
		size = 0;
	}
}
template <typename T>
void Queue<T>::reSize(const int& s)   
{
	T* data1 = new T[s]{};
	int* temp = new int [s] {};
	for (int i = 0; i < size; i++)
	{
		data1[i] = data[(front + i) % capacity];  //do this to make circular do that the data must be within the queue
		temp[i] = pArr[(front + i) % capacity];
	}
	front = 0;
	rear = size;
	delete[] data;
	delete[] pArr;
	capacity = s;
	data = data1;
	pArr = temp;
	data1 = NULL;
	temp = NULL;
}
template <typename T>
void Queue<T>::enQueue(const T& val, int p)    //insert or add the data to queue
{
	if (isFull())
		if (capacity)
			reSize(capacity * 2);
		else
		{
			data = new T[++capacity]{};
			pArr = new int [capacity] {};
		}
	rear = rear % capacity;

	data[rear] = val;
	pArr[rear] = p;
	rear++;
	size++;
}
template <typename T>
const T Queue<T>::deQueue(int p)  //remove data from queue
{
	if (isEmpty())
	{
		cout << "Queue is empty\n";
		exit(0);
	}
	else
	{
		if (size == capacity / 4)
			reSize(capacity / 2);
          front = front % capacity;
		for (int i = 0; i < size; i++)// loop to search the obj with periority p 
		{
			if (pArr[(front + i) % capacity] == p) // when found 
			{
				T temp = data[front]; // swap the data 
				data[front] = data[(front + i) % capacity];
				data[(front + i) % capacity] = temp;
				//now to assign the priority of the swaped obj
				pArr[(front + i) % capacity] = pArr[front];
			}
		}
		size--;
		return data[front++];
	}
}
template <typename T>
const int Queue<T>::getSize()
{
	return size;
}
template <typename T>
const int Queue<T>::getCapacity()
{
	return capacity;
}
template <typename T>
bool Queue<T>::isFull()const
{
	if (size == capacity)
		return true;
	else
		return false;
}
template <typename T>
bool Queue<T>::isEmpty()const
{
	if (size == 0)
		return true;
	else
		return false;
}
