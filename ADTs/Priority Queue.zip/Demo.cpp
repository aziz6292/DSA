//Abdul Aziz
//BCSF19A026
//CS Afternoon Add/drop
#include"Queue.h"
#include"Queue.cpp"

int main() {


	Queue<string> q;
	q.enQueue("Manager", 1);
	q.enQueue("Presedent", 2);
	q.enQueue("Clerk", 3);
	q.enQueue("Superviser", 4 );
	q.display();
	string a = q.deQueue(2);
	cout << a <<endl;
	string b = q.deQueue(1);
	cout << b <<endl;
	string c = q.deQueue(4);
	cout << c <<endl;
	string d = q.deQueue(3);
	cout << d <<endl;
	return 0;
}
