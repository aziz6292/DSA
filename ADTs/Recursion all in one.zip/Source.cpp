// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include <cstring>
#include <cctype>

using namespace std;
//*********************
//Funcions Prototypes *
//*********************

//Reciving in int value +ive or -ive
bool isEven(int);
//Sum of Digit of an int +ive or -ive
int sumOfDigit(long long int);
int noOfDigit(long long int n);
// Converting a no from Decimal to Binary
unsigned long long int dtob(int);
//**************
// Fabbonacci  *
// *************
//Calculating Sum of fabbonacci Series of to nth term 
//Using Indirect Recursion
unsigned long long sumOfFabbonacci(int, unsigned long long, unsigned long long);
//Prototype for user interface
unsigned long long sumOfFabbonacci(int);
//Finding nth Term of fabbonacci
unsigned long long fabbonacci(int);

//Finding index of largest value in an array of type int
int lar(int*, int, int);
int largest(int*, int);
//Same Can be implemented for Smallest value/index


//	**************
//	   Template  *
//	**************
//Recursion using Functions Template 

//Functions Template
//There are 2 2 functions overloading concept of tempalte for each logic
//1. searching key in array
template <class T>
bool search(T*, int, int, T);
template <class T>
bool search(T*, int, T);
//2. searching key index in array
template<class T>
int searchIndex(T*, int, int, T);
template <class T>
int searchIndex(T*, int, T);
//3. count occurance of key in array
template<class T>
int count(T* arr, int, int, T);
template <class T>
int count(T*, int, T);
//4. binary Search of key
template <class T>
bool bSearch(T*, int, int, T);
template <class T>
bool bSearch(T*, int, T);
//5. Recersing an array
template <class T>
void reverse(T*, int, int);
template <class T>
void reverse(T*, int);
//6. Dispalying an array
template <class T>
void display(T*, int);
//7. Sorting 
template <class T>
void sort(T[], int, int, int);
template <class T>
void sort(T[], int);
//Sum of odd elements of an array
int oddSum(int*, int, int);
int oddSum(int*, int);

//Tower of Hanoi is an famous puzzule algorithim 
// i.e reciveing int  no of disc 
// 3 tower source = A, temporary = B,  Destination = C
// your can move Disks from Source to Dest A->C using B as temprory
// method 
// 1st move from source to temp (taking dest as temporary)
// then move from temp to dest  (taking source as temp)
void ToH(int, char, char, char);


//Palindrome String is like abcdcba, aha, pop ete
bool isPalindrome(const char*, int, int);
bool isPalindrome(const char*);

//		Palindrome is a no like 101, 121,12321,10001,1001,1221,1002001 etc
//	The following functions use to solve the problem correctlly using Indirect Recursions
// 
// 1. Digit To No: 
// 
//		ie  if n =0 then 1, n = 1 then 10 n =2 then 100
//		 if n = 4 then 10000 if n = 5 then 100000 and so on..
// 
// 2. toSol0issue:
// 
//		ie if we check 100101001 so it mean it become 10100 instead of 0010100 
//		 so to make it 101 we use som logic 
// 
// 3. reverseNo:
// 
//		this one is smiple as 1234  become 4321 and so on

unsigned long long int digitToNo(int);
unsigned long long  toSol0Issue(unsigned long long, unsigned long long, unsigned long long);
unsigned long long int reverseNo(unsigned long long int, int);
bool isPalindrome(unsigned long long int);
bool isPalindrome1(unsigned long long int);

//Converting a str to a num (int type) i.e same as atoi(str)
int myAtoi(const char*, int);
int myAtoi(const char*);

//BackTracking Algorithims
//Finding the Sum of subsets of an int array
bool subsetSum(int*, int, int, int);
bool subsetSum(int*, int, int);
//Displaying the binary combinate or any combination possible of n with m 
// ie 00, 01, 10, 11
// ie AAA, AAB, AAC, ABA, ABB, ABC, ACA, ACB, ACC,....CCC.
template <class T>
void displayBinStr(int n, T* arr, int index);
void displayBinStr(int, char*, int);
// converting  ammoun in RS of possible combination to coins
// i.e How may ways 10, 20, 30 make 50
// 10+10+10+10+10, 10+10+10+20, 10+20+20, 10+10+30, 20+30 = 5 different way
int coinsChange(int*, int, int);


int main()
{
	const int SIZE = 4;
	int coins[SIZE] = { 10,20,30,35 };
	int  amount = 30;
	display(coins, SIZE);
	cout << "\nNo of Ways for above coins to make" << amount;
	cout << " is: " << coinsChange(coins, SIZE, amount) << endl;

	int ptrSize;
	cout << "Enter size for Combination of Binary (0,1) & String (A,B,C,D): ";
	cin >> ptrSize;
	int* ptr = new int[ptrSize];
	displayBinStr(ptrSize, ptr, 0);

	delete[]ptr;
	ptr = NULL;
	char* st = new char[ptrSize];
	displayBinStr(ptrSize, st, 0);
	char mystr[] = "1234";
	cout << "atoi function for " << mystr << " is: ";
	cout << myAtoi(mystr) << endl;
	delete[]st;
	st = NULL;


	const int N = 3;
	int  array[N] = { 2,5,-3 };
	
	cout << "Before Sorting\n";
	display(array, N);
	sort(array, N);
	cout << "After Sorting\n";
	display(array, N);
	cout << "\nSum of Odd elements of above array is: " << oddSum(array, N) << endl;
	int sum;
	cout << "\n\nEnter subsetSum to find in above array: ";
	cin >> sum;
	cout << "subsetSum found: " << subsetSum(array, 0, N - 1, sum) << endl;

	//Palindrome related Functions checkup
	unsigned long long int  num = 1234;
	cout << "No of Digit in " << num << " is: " << noOfDigit(num) << endl;
	cout << "Digit to No from " << num << " having Digit ";
	cout << noOfDigit(num) << " is: " << digitToNo(noOfDigit(num)) << endl;
	cout << "Reverse no of " << num << " is: " << reverseNo(num, noOfDigit(num)) << endl;
	unsigned long long  p = 100101001;
	cout << "Palindrome type(int) for " << p << " is: " << isPalindrome(p) << endl;

	char str[] = "abcscba";
	cout << "Str " << str << " Palindrome is: " << isPalindrome(str) << endl << endl;


	ToH(4, 'A', 'C', 'B');
	char cArr[] = "I am a programmer";
	cout << "\n\tChar\n\ncount: " << count(cArr, strlen(cArr), 'a') << endl;
	cout << "Index: " << searchIndex(cArr, strlen(cArr), 'z') << endl;
	cout << "Simple Search Found: " << search(cArr, strlen(cArr), 'f') << endl;
	
	cout << "Before Reverse: ";
	display(cArr, strlen(cArr));
	reverse(cArr, strlen(cArr));
	cout << "\nAfter Reverse:  ";
	display(cArr, strlen(cArr));
	cout << "\nBefore Sorting: ";
	display(cArr, strlen(cArr));
	sort(cArr, strlen(cArr));
	cout << "\nAfter Sorting:  ";
	display(cArr, strlen(cArr));
	cout << endl;
	cout << "Binary Search Found: " << bSearch(cArr, strlen(cArr), 'f') << endl;
	const int S = 5;
	double dArr[S] = { 12.2,-2.4,15.6,0.8,10.2 };
	cout << "\n\n\tDouble\n\nIndex: " << searchIndex(dArr, S,0.87) << endl;
	cout << "count: " << count(dArr, 0, 4, 0.8) << endl;
	cout << "Simple Search Found: " << search(dArr, S, 0.8) << endl;
	cout << "Before Reverse: ";
	display(dArr, S);
	reverse(dArr, S);
	cout << "\nAfter Reverse:  ";
	display(dArr, S);
	cout << "\nBefore Sorting: ";
	display(dArr, S);
	sort(dArr, S);
	cout << "\nAfter Sorting:  ";
	display(dArr, S);
	cout << endl;
	cout << "Binary Search Found: " << bSearch(dArr, S, 0.8) << endl;

	int arr[S] = { 70,180,85,90,-100 };
	cout << "\n\n\tInt\n\ncount: " << count(arr, S, 100) << endl;
	cout << "Index: " << searchIndex(arr, S, -100) << endl;
	cout << "Simple Search Found: " << search(arr, S, 100) << endl;
	cout << "Before Reverse: ";
	display(arr, S);
	reverse(arr, S);
	cout << "\nAfter Reverse:  ";
	display(arr, S);
	cout << "\nBefore Sorting: ";
	display(arr, S);
	sort(arr, S);
	cout << "\nAfter Sorting:  ";
	display(arr, S);
	cout << endl;
	cout << "Binary Search Found: " << bSearch(arr, S, 100) << endl;
	cout << "\nLargest element: " << arr[largest(arr, S)] << endl;

	int k = 7;
	cout << "\nSum of Fabonnacci up to " << k << "th term: " << sumOfFabbonacci(k) << endl;
	cout << "\nFabonnacci up to " << k << "th term: " << fabbonacci(k) << endl;

	int s = 16;
	cout << "\nDecimal to Binary of " << s << " is: " << dtob(s) << endl;

	int a = -984;
	cout << "\nSum of digit in " << a << " is: " << sumOfDigit(a) << endl << endl;
	cout << "No of digit in " << a << " is: " << noOfDigit(a) << endl << endl;

	int n = -17;
	if (isEven(n))
		cout << n << " is Even\n";
	else
		cout << n << " is Odd\n";

	unsigned long long int no;
	cout << "\nEnter no: ";
	cin >> no;
	cout << "\npalindrome logic Direct Recursion: " << isPalindrome(no) << endl;
	cout << "\nPalindrom logic Indirect Recursion: " << isPalindrome1(no) << endl;
	return 0;
}
bool isEven(int n)
{
	// cout<<n<<endl;
	if (n < 0)
		return isEven(n + 2);
	if (n == 1)
		return false;
	else if (n == 0)
		return true;
	else
		return isEven(n - 2);

}
int sumOfDigit(long long int n)
{
	int s = 0;
	if (n > 9 || n < -9)
		return (n % 10) + sumOfDigit(n / 10);
	return n;
}
int noOfDigit(long long int n)
{
	if (n >= -9 && n <= 9)
		return 1;
	else
	{
		int temp = noOfDigit(n / 10);
		return temp + 1;

	}

}
unsigned long long int dtob(int n)
{
	if (n)
		if (n % 2 == 1)
		{
			return 1 + 10 * dtob(n / 2);
		}
		else
			return 0 + 10 * dtob(n / 2);
	else return 0;

}

unsigned long long sumOfFabbonacci(int n, unsigned long long  a, unsigned long long  b)
{
	if (n)
		if (n == 1)
			return a + b;
		else if (n == 2)
			return a + b + 1;
		else
		{
			swap(a, b);
			b = a + b;
			return b + sumOfFabbonacci(n - 1, a, b);
		}
	return 0;
}
unsigned long long sumOfFabbonacci(int n)
{
	return sumOfFabbonacci(n, 0, 1);
}


unsigned long long fabbonacci(int n)
{
	if (n == 0)
		return 0;
	else if (n == 1)
		return 1;
	else

	{
		unsigned long long  sum1 = fabbonacci(n - 1);
		unsigned long long  sum2 = fabbonacci(n - 2);
		return  sum1 + sum2;

	}
}

int lar(int* arr, int start, int end)
{
	if (start == end)
		return start;
	else
	{
		int i = lar(arr, start + 1, end);
		if (arr[i] > arr[start])
			return i;
		else
			return start;

	}

}
int largest(int* arr, int n)
{
	return lar(arr, 0, n - 1);
}
//Functions Template 
template <class T>
bool search(T* arr, int start, int end, T key)
{
	bool flag = false;
	if (start <= end)
	{
		flag = search(arr, start + 1, end, key);
		if (arr[start] == key)
			flag = true;
		return flag;
	}
	else
		return flag;
}
template <class T>
bool search(T* arr, int n, T key)
{
	return search(arr, 0, n - 1, key);
}
template<class T>
int searchIndex(T* arr, int start, int end, T key)
{
	int flag = -1;
	if (start <= end)
	{
		flag = searchIndex(arr, start + 1, end, key);
		if (arr[start] == key)
			flag = start;
		return flag;
	}
	else
		return flag;
}
template <class T>
int searchIndex(T* arr, int n, T key)
{
	return searchIndex(arr, 0, n - 1, key);
}




template<class T>
int count(T* arr, int start, int end, T key)
{
	int flag = 0;
	if (start > end)
		return 0;

	else
	{
		int flag = count(arr, start + 1, end, key);
		if (arr[start] == key)
			flag++;
		return flag;
	}
}
template <class T>
int count(T* arr, int n, T key)
{
	return count(arr, 0, n - 1, key);
}


template <class T>
bool bSearch(T* arr, int start, int end, T key)
{
	if (start <= end)
	{
		int mid = (start + end) / 2;
		if (arr[mid] == key)
			return true;
		else if (arr[mid] > key)
			return bSearch(arr, start, mid - 1, key);
		else
			return bSearch(arr, mid + 1, end, key);
	}
	else
		return false;
}
template <class T>
bool bSearch(T* arr, int n, T key)
{
	return bSearch(arr, 0, n - 1, key);
}
template <class T>
void reverse(T* arr, int start, int end)
{
	if (start < end)
	{
		swap(arr[start], arr[end]);
		reverse(arr, start + 1, end - 1);
	}

}
template <class T>
void reverse(T* arr, int n)
{
	reverse(arr, 0, n - 1);
}
template <class T>
void display(T* arr, int size)
{
	if (size)
	{
		display(arr, --size);
		cout << arr[size] << " ";
	}
}

void ToH(int n, char src, char dest, char temp)
{
	if (n > 0)
	{
		if (n == 1)
			cout << "Move Disk #" << n << " from " << src << " to " << dest << endl;
		else
		{
			ToH(n - 1, src, temp, dest);
			cout << "Move Disk #" << n << " from " << src << " to " << dest << endl;
			ToH(n - 1, temp, dest, src);
		}
	}
}
bool isPalindrome(const char* str, int start, int end)
{
	if (start >= end)
		return true;
	else if (str[start] != str[end])
		return false;
	else
		return isPalindrome(str, start + 1, end - 1);
}
bool isPalindrome(const char* str)
{
	return isPalindrome(str, 0, strlen(str) - 1);
}
unsigned long long int digitToNo(int n)
{
	if (n)
		return 10 * digitToNo(n - 1);
	else
		return 1;
}
unsigned long long  toSol0Issue(unsigned long long val, unsigned long long temp, unsigned long long i)
{

	if (val >= temp / i)
		return 1;
	else
		return 10 * toSol0Issue(val, temp, i * 10);

}
bool isPalindrome(unsigned long long int val)
{

	if (val == 0)
		return true;
	else
	{
		unsigned long long int a = val % 10;
		unsigned long long int temp = val;
		unsigned long long int b = 1;
		unsigned long long int i = 100, j = 1;
		b = digitToNo(noOfDigit(temp));
		b = b / 10;
		temp = b;
		b = val / b;
		val = (val % temp) / 10;
		j = toSol0Issue(val, temp, i);
		val = val / j;
		//cout<<a<<" "<<b<< " "<<j<<" "<<temp/i <<" "<<val<<endl;

		if (a != b)
			return false;

		else
			return isPalindrome(val);

	}
}




unsigned long long int reverseNo(unsigned long long int val, int n)
{
	unsigned long long int i = digitToNo(n) / 10;
	//i = digitToNo(n -1);
	//for(i =1, j=0; j<n; j++, i=i*10);
	//i = i / 10;
	//cout<<i<<" "<<k<<endl;

	if (val)
	{
		if (i == val && i >= 10)
			return 1;
		else
			return 10 * reverseNo(val % i, --n) + val / i;
	}
}

bool isPalindrome1(unsigned long long int val)
{
	if (val)
	{
		int k = noOfDigit(val);
		if (val % 10 != reverseNo(val, k) % 10)
			return false;
		else
		{
			val = val / 10;
			return isPalindrome1(reverseNo(val, --k) / 10);
		}
	}
	else
		return true;
}
int myAtoi(const char* str, int n)
{
	if (n == 1)
		return str[0] - 48;
	else
		return 10 * myAtoi(str, n - 1) + (str[n - 1] - 48);

}
int myAtoi(const char* str)
{
	return myAtoi(str, strlen(str));
}
bool subsetSum(int* arr, int start, int end, int sum)
{
	cout << sum << " " << start << " " << arr[start] << endl;
	if (sum == 0)
		return true;
	else if (start == end)
		if (arr[start] == sum)
			return true;
		else
			return false;
	else
	{
		bool flag1 = subsetSum(arr, start + 1, end, sum);
		cout << endl << endl;
		bool flag2 = subsetSum(arr, start + 1, end, sum - arr[start]);
		if (flag1 || flag2)
			return true;
		else
			return false;
	}
}
bool subsetSum(int* arr, int n, int sum)
{
	return subsetSum(arr, 0, n - 1, sum);
}

void displayBinStr(int n, char* arr, int index)
{
	if (index == n)
	{
		display(arr, n);
		cout << endl;
	}
	else
	{
		arr[index] = 'A';
		displayBinStr(n, arr, index + 1);
		arr[index] = 'B';
		displayBinStr(n, arr, index + 1);
		arr[index] = 'C';
		displayBinStr(n, arr, index + 1);
		arr[index] = 'D';
		displayBinStr(n, arr, index + 1);
	}
}
int coinsChange(int* arr, int noOfCoins, int amount)
{
	if (amount == 0)
		return 1;
	else if (noOfCoins <= 0 || amount < 0)
		return 0;
	else
	{
		int temp1 = coinsChange(arr, noOfCoins, amount - arr[noOfCoins - 1]);
		int temp2 = coinsChange(arr, noOfCoins - 1, amount);
		return temp1 + temp2;
	}

}
template <class T>
void displayBinStr(int n, T* arr, int index)
{
	if (index == n)
	{
		display(arr, n);
		cout << endl;
	}
	else
	{
		arr[index] = 0;
		displayBinStr(n, arr, index + 1);
		arr[index] = 1;
		displayBinStr(n, arr, index + 1);
		//arr[index]=2;
		//displayBinStr(n,arr, index+1);
		//arr[index]=3;
		//(n,arr, index+1);
	}
}
template <class T>
void sort(T a[], int i, int s, int c)
{
	if (i == s - 1)
	{
		if (c != 0)
		{

			c = 0;
			i = 0;
			sort(a, i, s, c);
		}
	}
	else
	{
		if (a[i] > a[i + 1])
		{
			c++;
			swap(a[i], a[i + 1]);
		}
		sort(a, ++i, s, c);
	}
}
template <class T>
void sort(T arr[], int n)
{
	sort(arr, 0, n, 0);
}

//Sum of Odd element of array
int oddSum(int* arr, int start, int end)
{
	int sum = 0;
	if (start <= end)
	{
		if (arr[start] % 2 != 0)
			sum = arr[start];
		sum = sum + oddSum(arr, start + 1, end);
	}
	return sum;
}
int oddSum(int* arr, int n)
{
	return oddSum(arr, 0, n - 1);
}