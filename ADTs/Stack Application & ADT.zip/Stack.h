#ifndef STACK_H
#define STACK_H
#include <iostream>
#include <string>
#include <cctype>
#include <string>
#include <cmath>
using namespace std;
template <typename T>
class Stack
{
private:
    /* data */
    T *data;
    int capacity;
    int top;
    void reSize(const int &);

public:
    Stack();
    Stack(const Stack<T> &);
    const Stack<T> &operator=(const Stack<T> &);
    ~Stack();
    // Functions
    void push(const T &);
    const T &pop();
    const T &stackTop();
    bool isFull() const;
    bool isEmpty() const;
    const int getCapacity();
    const int getNumberOfElement();
    void display()
    {
        cout << "Data: ";
        for (int i = 0; i <= top; i++)
        {
            cout << data[i] << " ";
        }
        cout << endl;
    }
};
#endif