#include "Stack.h"
#include "Stack.cpp"
bool check(string);
int neededParentheses(string);
string sumNumbers(string, string);
string infixToPostfix(string);
string chemicalFormula(string);
int postfixEvaluationInt(string);
string postfixEvaluationStr(string);
bool isPalindrome(string);
int sol(int, int, char);
int infixEvaluationInt(string);
const int row = 9, col = 8;
struct Pair
{
    int r;
    int c;
};
bool mazeSolution(int **, Pair, Pair);
int main()
{
    //Maze Solution Backtracking 
    int **maze = new int *[row] {};
    for (int i = 0; i < row; i++)
        maze[i] = new int[col]{};
    int mazeC[row][col] = {{0, 1, 0, 0, 0, 1, 1, 0},
                           {0, 1, 1, 0, 0, 0, 0, 0},
                           {1, 1, 1, 1, 1, 1, 0, 1},
                           {1, 0, 1, 0, 1, 1, 1, 1},
                           {0, 0, 1, 1, 1, 1, 0, 1},
                           {1, 1, 1, 0, 1, 1, 1, 1},
                           {1, 1, 1, 0, 0, 1, 1, 0},
                           {1, 1, 1, 1, 1, 1, 1, 1},
                           {1, 0, 1, 0, 1, 0, 1, 1}};
    for (int i = 0; i < row; i++)
        for (int j = 0; j < col; j++)
            maze[i][j] = mazeC[i][j];
    Pair source, destination;
    cout << "Enter Source: ";
    cin >> source.r >> source.c;
    cout << "Enter Destination: ";
    cin >> destination.r >> destination.c;
    if (mazeSolution(maze, source, destination))
        cout << "Found\n";
    else
        cout << "Not Found\n";

    //Infix String Evaluation 
    string infix;
    cout << "Enter infix String to Evaluate: ";
    getline(cin, infix);
    cout << "Infix Evaluation is: " << infixEvaluationInt(infix) << endl;
    //Palindrome 
    string palindromeStr;
    cout << "Enter Sentence to Check if Palindrome: ";
    getline(cin, palindromeStr);
    if (isPalindrome(palindromeStr))
        cout << "\nYes! it is Palindrome\n";
    else
        cout << "\nNo! it is not Palindrome\n";
    //Postfix Evaluation to String and Int
    string postfix, postfix1;
    cout << "Enter Expression in Postfix to Evaluate to (Int): ";
    getline(cin, postfix);
    cout << "Output: " << postfixEvaluationInt(postfix) << endl;
    cout << "Enter Expression in Postfix to Evaluate to (String): ";
    getline(cin, postfix1);
    cout << "Output: " << postfixEvaluationStr(postfix1) << endl;

    // Task Chemical Formula
    string formula;
    cout << "Chemical Formula: ";
    getline(cin, formula);
    cout << "Output: " << chemicalFormula(formula) << endl;
    Stack<int> stack{};
    for (int i = 0; i < 10; i++)
        stack.push(i);
    for (int i = 0; i < 10; i++)
        cout << stack.pop() << " ";

    string str;
    // Task 01
    cout << "\n\nEnter the Mathematical Expression: ";
    getline(cin, str);
    if (check(str))
        cout << "Balanced\n";
    else
        cout << "Not Balanced\n";
    // Task 03 //Needed Parantheses
    cout << "Eneter The Parantheses to Check () only: ";
    cin >> str;
    cout << "No of Prentheses needed to Balance the " << str << " is: ";
    cout << neededParentheses(str) << endl;
    // Task 02
    string a, b, result;
    cout << "Enter first number: ";
    cin >> a;
    cout << "Enter second number: ";
    cin >> b;
    result = sumNumbers(a, b);
    cout << "\n\t" << a << "\n+\t" << b << "\n=\t" << result << endl;
    // Task Expression
    cout << "Enter Expression to convert (infix to postfix): ";
    cin.ignore();
    getline(cin, str);
    str = infixToPostfix(str);
    cout << str << endl;
    return 0;
}
bool check(string str)
{
    Stack<char> arr;
    for (int i = 0; i < str.size(); i++)
    {
        if (str[i] == '(' || str[i] == '{' || str[i] == '[')
            arr.push(str[i]);
        else if (str[i] == ')')
        {
            if (arr.pop() != '(')
                return false;
        }
        else if (str[i] == '}')
        {
            if (arr.pop() != '{')
                return false;
        }
        else if (str[i] == ']')
        {
            if (arr.pop() != '[')
                return false;
        }
    }
    if (!arr.isEmpty())
        return false;
    return true;
}
int neededParentheses(string str)
{
    Stack<char> arr;
    int count = 0;
    for (int i = 0; i < str.size(); i++)
    {
        if (str[i] == '(')
            arr.push(str[i]);
        else if (str[i] == ')' && !arr.isEmpty())
        {
            arr.pop();
        }
        else if (str[i] == ')' && arr.isEmpty())
        {
            count++;
        }
    }
    return count + arr.getNumberOfElement();
}
string sumNumbers(string a, string b)
{
    int i = 1;
    int j = 1;
    int k = 0;
    int l = 0;
    bool flag1 = false, flag2 = false;
    bool sign = false;
    while (a[k] == '0')
        k++;
    while (b[l] == '0')
        l++;
    if (a[k] == '-')
    {
        flag1 = true;
        k++;
    }
    if (b[l] == '-')
    {
        flag2 = true;
        l++;
    }
    if ((flag1 && !flag2) || (!flag1 && flag2))
        sign = true;

    Stack<int> result;
    int reminder = 0;
    int sumDigit = 0;
    while (i <= a.size() - k && j <= b.size() - l)
    {

        sumDigit = (a[a.size() - i] - 48) + (b[b.size() - j] - 48) + reminder;
        if (sumDigit > 9)
        {
            reminder = 1;
        }
        else
        {
            reminder = 0;
        }
        result.push(sumDigit % 10);
        i++;
        j++;
    }
    if (i <= a.size() - k)
    {
        while (i <= a.size() - k)
        {
            sumDigit = (a[a.size() - i] - 48) + reminder;
            if (sumDigit > 9)
            {
                reminder = 1;
            }
            else
            {
                reminder = 0;
            }
            result.push(sumDigit % 10);
            i++;
        }
    }
    else
    {
        while (j <= b.size() - l)
        {
            sumDigit = (b[b.size() - j] - 48) + reminder;
            if (sumDigit > 9)
            {
                reminder = 1;
            }
            else
            {
                reminder = 0;
            }
            result.push(sumDigit % 10);
            j++;
        }
    }
    if (reminder == 1)
        result.push(reminder);

    cout << "Output: ";
    if (flag1 && flag2)
        cout << "-";
    string ans = "";
    while (!result.isEmpty())
        ans += result.pop() + 48;
    return ans;
}
string infixToPostfix(string str)
{
    string result = "";
    int i = 0;
    Stack<char> stack;
    while (str[i] != '\0')
    {
        if (str[i] == '(')
            stack.push(str[i]);
        else if (str[i] == '+' || str[i] == '-')
        {
            while (!stack.isEmpty() && stack.stackTop() != '(')
                result += stack.pop();
            stack.push(str[i]);
        }
        else if (str[i] == ')')
        {
            while (stack.stackTop() != '(')
            {
                result += stack.pop();
            }
            stack.pop();
        }
        else if (str[i] == '^')
        {
            if (stack.stackTop() == '^')
                result += stack.pop();
            stack.push(str[i]);
        }
        else if (str[i] == '*' || str[i] == '/')
        {
            if (stack.stackTop() == '^')
                result += stack.pop();
            if (stack.stackTop() == '/' || stack.stackTop() == '*')
                result += stack.pop();
            stack.push(str[i]);
        }
        else
        {
            result += str[i];
        }
        cout << result << endl;
        i++;
    }
    while (!stack.isEmpty())
        result += stack.pop();
    return result;
}
string chemicalFormula(string str)
{
    int i = 0;
    string result = "";
    // To place count after each element.
    while (str[i])
    {
        if (str[i] == '(' || str[i] == ')')
        {
            result += str[i];
            int j = i + 1;
            while (isdigit(str[j]))
                result += str[j++];
        }
        else if (isupper(str[i]))
        {
            result += str[i];
            int j = i + 1;
            while (islower(str[j]))
                result += str[j++];
            if (isdigit(str[j]))
            {
                while (isdigit(str[j]))
                    result += str[j++];
            }
            else
                result += '1';
        }
        i++;
    }
    string formula = result;
    Stack<char> s{};
    Stack<char> r{};
    i = 0;
    // Now to resolve the parentheses and multiply
    // the each Element with
    // the Number
    while (formula[i])
    {
        auto a = formula[i];
        i++;
        if (a != ')')
            s.push(a);
        else
        {
            if (isdigit(formula[i]))
            {
                int mul = 0;
                while (isdigit(formula[i]))
                    mul = mul * 10 + (formula[i++] - 48);
                while (s.stackTop() != '(')
                {
                    int temp = 0;
                    if (isdigit(s.stackTop()))
                    {
                        while (isdigit(s.stackTop()))
                        {
                            temp = temp + mul * (s.pop() - 48);
                            r.push(temp % 10 + 48);
                            temp = temp / 10;
                        }
                        if (temp)
                            r.push(temp + 48);
                    }
                    else
                        r.push(s.pop());
                }
                s.pop();
                while (!r.isEmpty())
                    s.push(r.pop());
            }
        }
    }
    // To collect The Result
    while (!s.isEmpty())
        r.push(s.pop());
    result = "";
    while (!r.isEmpty())
        result += r.pop();
    // Finally to Sum the Multiple count of same Element
    //  in the given Formula
    string *arr = new string[result.length()]{""};
    i = 0;
    int j = 0;
    while (i < result.length())
    {
        if (isalpha(result[i]))
        {
            while (isalpha(result[i]))
                arr[j] += result[i++];
            j++;
        }
        else if (isdigit(result[i]))
        {
            while (isdigit(result[i]))
                arr[j] += result[i++];
            j++;
        }
        else
        {
            i++;
        }
    }
    int count = 0;
    string output = "";
    for (int i = 0; i < j; i = i + 2)
    {
        count = stoi(arr[i + 1]);
        for (int k = i + 2; k < j; k = k + 2)
        {
            if (arr[i] == arr[k])
            {
                count += stoi(arr[k + 1]);
                int l = k;
                while (l + 2 < j)
                {
                    arr[l] = arr[l + 2];
                    arr[l + 1] = arr[l + 3];
                    l = l + 2;
                }
                j = j - 2;
            }
        }
        output += arr[i];
        if (count > 1)
            output += to_string(count);
    }
    delete[] arr;
    arr = NULL;
    return output;
}
int postfixEvaluationInt(string str)
{
    Stack<int> obj;
    int i = 0;
    while (i < str.length())
    {

        if (str[i] == '+' || str[i] == '-' || str[i] == '*' || str[i] == '/' || str[i] == '^')
        {
            int a = 0, b = 0;
            if (!obj.isEmpty())
            {
                a = obj.pop();
                b = obj.pop();
            }
            if (str[i] == '^')
            {

                obj.push(pow(b, a));
            }
            else if (str[i] == '+')
            {

                obj.push(b + a);
            }
            else if (str[i] == '-')
            {
                obj.push(b - a);
            }
            else if (str[i] == '*')
            {

                obj.push(b * a);
            }
            else if (str[i] == '/')
            {
                obj.push((b / a));
            }
            i++;
        }
        else
        {
            int n = 0;
            while (isdigit(str[i]))
            {
                n = n * 10 + str[i] - 48;
                i++;
            }
            if (n)
                obj.push(n);
            else
                i++;
        }
    }
    return obj.pop();
}
string postfixEvaluationStr(string str)
{
    Stack<string> obj;
    int i = 0;
    while (i < str.length())
    {
        if (isalpha(str[i]))
        {
            string s = "";
            s += str[i];
            obj.push(s);
        }
        else
        {
            string s1 = "";
            s1 = obj.pop();
            s1 += ")";
            string s2 = "";
            s2 += "(";
            s2 += obj.pop();
            s2 += str[i];
            s2 += s1;
            obj.push(s2);
        }
        i++;
    }
    return obj.pop();
}
bool isPalindrome(string str)
{
    int i = str.length() / 2;
    Stack<char> st;
    while (i < str.length())
    {
        if (isalpha(str[i]) || isdigit(str[i]))
            st.push(str[i]);
        i++;
    }
    i = 0;
    while (!st.isEmpty())
    {
        if (isalpha(str[i]) || isdigit(str[i]))
            if (toupper(str[i]) != toupper(st.pop()))
                return false;
        i++;
    }
    return true;
}
int sol(int a, int b, char c)
{
    switch (c)
    {
    case '+':
        return a + b;
    case '-':
        return a - b;
    case '*':
        return a * b;
    case '/':
        return a / b;
    case '^':
        return pow(a, b);
    case '%':
        return a % b;
    }
    cout << "Invalid String\n";
    exit(0);
}
int infixEvaluationInt(string str)
{
    if (check(str))
    {
        int i = 0;
        Stack<int> opnd;
        Stack<char> optr;
        while (i < str.length())
        {
            if (isdigit(str[i]))
            {
                int num = 0;
                while (isdigit(str[i]))
                {
                    num = num * 10 + (str[i] - 48);
                    i++;
                }
                opnd.push(num);
            }
            else if (isspace(str[i]) || str[i] == ',')
            {
                i++;
            }
            else if (str[i] == '(' || str[i] == '{' || str[i] == '[')
            {
                optr.push(str[i]);
                i++;
            }
            else if (str[i] == '}' || str[i] == ']' || str[i] == ')')
            {
                while (optr.stackTop() != '(' && optr.stackTop() != '{' && optr.stackTop() != '[')
                {
                    char c = optr.pop();
                    int b = opnd.pop();
                    int a = opnd.pop();
                    opnd.push(sol(a, b, c));
                }
                optr.pop();
                i++;
            }
            else if (str[i] == '+' || str[i] == '-')
            {
                while (!optr.isEmpty() && optr.stackTop() != '(' && optr.stackTop() != '{' && optr.stackTop() != '[')
                {
                    char c = optr.pop();
                    int b = opnd.pop();
                    int a = opnd.pop();
                    opnd.push(sol(a, b, c));
                }
                optr.push(str[i]);
                i++;
            }
            else if (str[i] == '*' || str[i] == '/' || str[i] == '%')
            {
                while (!optr.isEmpty() && (optr.stackTop() == '^' || optr.stackTop() == '*' || optr.stackTop() == '/' || optr.stackTop() == '%'))
                {
                    char c = optr.pop();
                    int b = opnd.pop();
                    int a = opnd.pop();
                    opnd.push(sol(a, b, c));
                }
                optr.push(str[i]);
                i++;
            }
            else if (str[i] == '^')
            {
                if (!optr.isEmpty() && optr.stackTop() == '^')
                {
                    i++;
                    while (isspace(str[i]))
                        i++;
                    int a = 0;
                    while (isdigit(str[i]))
                        a = a * 10 + (str[i++] - 48);
                    char c = optr.pop();
                    int b = opnd.pop();
                    opnd.push(sol(a, b, c));
                    optr.push('^');
                }
                else
                {
                    optr.push('^');
                    i++;
                }
            }
            else
            {
                cout << "invalid String\n";
                exit(0);
            }
        }
        while (!optr.isEmpty())
        {
            char c = optr.pop();
            int b = opnd.pop();
            int a = opnd.pop();
            opnd.push(sol(a, b, c));
        }
        return opnd.pop();
    }
    else
    {
        cout << "Not Balance Sentense\n";
        exit(0);
    }
}
bool mazeSolution(int **maze, Pair source, Pair destination)
{
    Stack<Pair> path;
    path.push(source);
    Pair temp;
    int i = source.r;
    int j = source.c;
    temp = source;
    maze[i][j] = 2;
    bool flag = false;
    while (!flag && !path.isEmpty())
    {
        if (temp.r == destination.r && temp.c == destination.c)
            flag = true;
        else
        {
            if (i > 0 && maze[i - 1][j] == 1)
                i--;
            else if (j > 0 && maze[i][j - 1] == 1)
                j--;
            else if (i < (row - 1) && maze[i + 1][j] == 1)
                i++;
            else if (j < (col - 1) && maze[i][j + 1] == 1)
                j++;
            else
                temp = path.pop();
            if (temp.r == i && temp.c == j)
            {
                if (maze[i][j] == 2)
                {
                    maze[i][j] = 3;
                    if (path.isEmpty())
                        break;
                    i = path.stackTop().r;
                    j = path.stackTop().c;
                }
                else
                    maze[i][j] = 3;
            }
            else
            {
                temp.r = i;
                temp.c = j;
                path.push(temp);
                maze[i][j] = 2;
            }
        }
    }
    while (!path.isEmpty())
    {
        temp = path.pop();
        cout << "(" << temp.r << "," << temp.c << ")\n";
    }
    return flag;
}