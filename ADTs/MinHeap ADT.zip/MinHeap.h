//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************

#ifndef MINHEAP_H
#define MINHEAP_H
#include <iostream>
using namespace std;
template <typename T>
class MinHeap
{
    T *heap;
    int curSize, maxSize;
    void reSize(int);

public:
    MinHeap(int = 0);
    MinHeap(const MinHeap &);
    const MinHeap &operator=(const MinHeap &);
    ~MinHeap();
    void insert(T);
    bool deleteMin();
    bool isEmpty();
    bool isFull();
    T getMin();
    void print() const;
    void heapify(int);
    void buildHeap(T *, int);
};
#endif