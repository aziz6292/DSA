//****************************************************************
//              Abdul Aziz
//              BCSF19A026
//              CS Afternoon Add/Drop
//****************************************************************
#include "MinHeap.h"

template <typename T>
void MinHeap<T>::reSize(int size)
{
    if (size <= 0 || maxSize == 0)
        size = 1;
    T *tempHeap = new T[size]{};
    for (int i = 0; i < curSize; i++)
        tempHeap[i] = heap[i];
    int tempCount = curSize;
    this->~MinHeap();
    heap = new T[size]{};
    for (int i = 0; i < tempCount; i++)
        heap[i] = tempHeap[i];
    maxSize = size;
    curSize = tempCount;
    tempHeap = NULL;
}
template <typename T>
MinHeap<T>::MinHeap(int size) : maxSize(size), curSize(0), heap(NULL)
{
    if (size > 0)
        heap = new T[size]{};
}
template <typename T>
MinHeap<T>::MinHeap(const MinHeap<T> &obj)
{
    curSize = obj.curSize;
    maxSize = obj.maxSize;
    heap = new T[maxSize];
    for (int i = 0; i < curSize; ++i)
        heap[i] = obj.heap[i];
}
template <typename T>
const MinHeap<T> &MinHeap<T>::operator=(const MinHeap<T> &obj)
{
    if (this == &obj)
        return *this;
    if (heap)
        this->~MinHeap();
    curSize = obj.curSize;
    maxSize = obj.maxSize;
    heap = new T[maxSize];
    for (int i = 0; i < curSize; ++i)
        heap[i] = obj.heap[i];
    return *this;
}
template <typename T>
MinHeap<T>::~MinHeap()
{
    if (heap)
    {
        delete[] heap;
        heap = NULL;
    }
}
template <typename T>
void MinHeap<T>::insert(T data)
{
    if (isFull())
        reSize(maxSize * 2);
    int i = curSize;
    while (i && (i - 1) / 2 >= 0 && data < heap[(i - 1) / 2])
    {
        heap[i] = heap[(i - 1) / 2];
        i = (i - 1) / 2;
    }
    curSize++;
    heap[i] = data;
}
template <typename T>
bool MinHeap<T>::deleteMin()
{
    if (isEmpty())
    {
        cout << "heap is empty" << endl;
        return false;
    }
    if (curSize == maxSize / 4)
        reSize(maxSize / 2);
    swap(heap[0], heap[--curSize]);
    int i = 0;
    int min, left = i * 2 + 1, right = i * 2 + 2;
    bool isSmallest = false;
    while (left < curSize && !isSmallest) // loop until we not find a greater value than heap[i].
    {
        min = i;
        if (heap[min] > heap[left])
            min = left;
        if (right < curSize && heap[min] > heap[right])
            min = right;
        if (min == i) // mean that node value is less than it's childs value
            isSmallest = true;
        else
        {
            swap(heap[i], heap[min]);
            i = min;
            left = i * 2 + 1;
            right = i * 2 + 2;
        }
    }
    return true;
}
template <typename T>
bool MinHeap<T>::isEmpty()
{
    return curSize == 0;
}
template <typename T>
bool MinHeap<T>::isFull()
{
    return curSize == maxSize;
}
template <typename T>
T MinHeap<T>::getMin()
{
    return heap[0];
}
template <typename T>
void MinHeap<T>::print() const
{
    for (int i = 0; i < curSize; ++i)
        cout << heap[i] << " ";
    cout << endl;
}
template <typename T>
void MinHeap<T>::heapify(int i)
{
    int min, left = i * 2 + 1, right = i * 2 + 2;
    bool isSmallest = false;
    while (left < curSize && !isSmallest) // loop until we not find a greater value than heap[i].
    {
        min = i;
        if (heap[min] > heap[left])
            min = left;
        if (right < curSize && heap[min] > heap[right])
            min = right;
        if (min == i) // mean that node value is less than it's childs value
            isSmallest = true;
        else
        {
            swap(heap[i], heap[min]);
            i = min;
            left = i * 2 + 1;
            right = i * 2 + 2;
        }
    }
}
template <typename T>
void MinHeap<T>::buildHeap(T *arr, int size)
{
    if (heap)
        this->~MinHeap();
    maxSize = curSize = size;
    heap = new T[maxSize]{};
    for (int i = 0; i < size; i++)
        heap[i] = arr[i];
    int i = size / 2;
    while (i >= 0)
    {
        heapify(i);
        i--;
    }
}