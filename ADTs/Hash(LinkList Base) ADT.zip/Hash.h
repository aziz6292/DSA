#ifndef HASH_H
#define HASH_H 
#include "HashLL.cpp"
template <typename T>
class Hash
{
    HashLL<T> *table;
    int size;
    int maxSize;

public:
    friend class HashLL<T>;
    Hash(int);
    Hash(const Hash &);
    const Hash &operator=(const Hash &);
    ~Hash();
    void insert(T, int);
    void remove(T, int);
    Node<T> *search(T, int);
    void display();
};
#endif
