#include <iostream>
#include "stdint.h"
#include <queue>
#include<stack>
using namespace std;
template <class T>
struct node
{
public:
	int info;
	int height;
	node<T> *left;
	node<T> *right;
	node(T val = 0)
	{
		info = val;
		left = nullptr;
		right = nullptr;
		height = 1;
	}
};
template <class T>
class AVL
{
	node<T> *root;

public:
	AVL()
	{
		root = nullptr;
	}
	void insert(T val)
	{
		node<T> *p = root;
		node<T> *child = new node<T>(val);
		if (!root)
		{
			root = child;
			return;
		}
		else
		{
			stack<node<T> *> st;
			bool flag = false;
			node<T> * pre = nullptr;
			while (p)
			{
				st.push(p);
				if (val < p->info)
				{
					pre = p;
				    p = p->left;
				}
				else if (val >= p->info)
				{
					    pre = p;
						p = p->right;
					
				}
			}
			st.push(child);
			if (pre->info > child->info)
			pre->left = child;
			else 
			pre->right = child;
			node<T> *p1 = st.top(), *p2 = nullptr;
			st.pop();
			while (!st.empty())
			{
				p2 = st.top();
				st.pop();
				if (p1->height == p2->height)
					p2->height++;
				if (getBalanceFactor(p2) < -1 || getBalanceFactor(p2) > 1)
					rotation(p2);
				p1 = p2;

			}
		}
	}
	void Print(node<T> *p)
	{
		if (!p)
			return;
		Print(p->left);
		cout << p->info << " ";
		Print(p->right);
	}

	node<T> *getRoot()
	{
		return root;
	}
	int height(node<T> *p)
	{
		if (p == nullptr)
		{
			return 0;
		}
		int leftHeight = height(p->left);
		int rightHeight = height(p->right);
		if (leftHeight > rightHeight)
			return (leftHeight + 1);
		else
			return (rightHeight + 1);
	}
	int heightfactor(node<T> *p)
	{
		if (p == nullptr)
		{
			return -1;
		}
		int leftHeight = heightfactor(p->left);
		int rightHeight = heightfactor(p->right);
		if (leftHeight > rightHeight)
			p->height = leftHeight + 1;
		else
			p->height = rightHeight + 1;
		return (p->height);
	}
	void rotation(node<T> *p)
	{
		if (p->left != nullptr && p->left->left != nullptr)
		{
			LL(p);
		}
		else if (p->left != nullptr && p->left->right != nullptr)
		{
			LR(p);
		}
		else if (p->right != nullptr && p->right->left != nullptr)
		{
			RL(p);
		}
		else if (p->right != nullptr && p->right->right != nullptr)
		{
			RR(p);
		}
	}
	void LL(node<T> *gParent)
	{
		int key = gParent->info;
		node<T> *parent = gParent->left;
		node<T> *child = parent->left;
		gParent->info = parent->info;
		gParent->left = parent->left;
		gParent->right = parent;
		parent->info = key;
		parent->left = nullptr;
	}
	void display()
	{
		queue<node<T> *> que;
		que.push(root);
		node<T> *temp;
		int h = height(root);
		int i = 1;
		while (h--)
		{
			int j = 0;
			while (j++ < h)
				cout << " ";
			j = 0;
			while (j < i)
			{
				temp = que.front();
				que.pop();
				if (temp && temp->left)
					que.push(temp->left);
				else
					que.push(nullptr);
				if (temp && temp->right)
					que.push(temp->right);
				else
					que.push(nullptr);
				if (temp)
					cout << temp->info << " ";
				else
					cout << " ";
				j++;
			}
			i = i * 2;
			cout << endl;
		}
	}
	void displayheight()
	{
		queue<node<T> *> que;
		que.push(root);
		node<T> *temp;
		int h = height(root);
		int i = 1;
		while (h--)
		{
			int j = 0;
			while (j++ < h)
				cout << " ";
			j = 0;
			while (j < i)
			{
				temp = que.front();
				que.pop();
				if (temp && temp->left)
					que.push(temp->left);
				else
					que.push(nullptr);
				if (temp && temp->right)
					que.push(temp->right);
				else
					que.push(nullptr);
				if (temp)
					cout << temp->height << " ";
				else
					cout << " ";
				j++;
			}
			i = i * 2;
			cout << endl;
		}
	}
	int getBalanceFactor(node<T> *q)
	{
		if (!q)
			return 0;
		if (q->left && q->right)
			return q->left->height - q->right->height;
		if (q->left && !q->right)
			return q->left->height;
		if (q->right && !q->left)
			return q->right->height;
		if (!q->left && !q->right)
			return 0;
	}
	void RR(node<T> *gParent)
	{
		int key = gParent->info;
		node<T> *parent = gParent->right;
		node<T> *child = parent->right;
		gParent->info = parent->info;
		gParent->right = parent->right;
		gParent->left = parent;
		parent->info = key;
		parent->right = nullptr;
	}
	void LR(node<T> *gParent)
	{
		int key = gParent->info;
		node<T> *parent = gParent->left;
		node<T> *child = parent->right;
		gParent->info = child->info;
		gParent->right = child;
		child->info = key;
		parent->right = nullptr;
	}
	void RL(node<T> *gParent)
	{
		int key = gParent->info;
		node<T> *parent = gParent->right;
		node<T> *child = parent->left;
		gParent->info = child->info;
		gParent->left = child;
		child->info = key;
		parent->left = nullptr;
	}
};
int main()
{
	AVL<int> a;
	a.insert(20);
	a.insert(15);
	a.insert(10);
	a.insert(5);
	a.insert(4);
	a.insert(3);
	a.insert(2);
	a.insert(1);
	a.Print(a.getRoot());
	cout << endl;
	a.display();
}