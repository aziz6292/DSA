// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#ifndef HLL_H
#define HLL_H
#include <iostream>
using namespace std;
template <typename T>
class HashLL;
template <typename T>
class Node
{
    T data;
    Node<T> *next;

public:
    friend class HashLL<T>;
    Node(T d = 0) : data(d), next(NULL) {}
    friend ostream &operator<<(ostream &out, const Node<T> &obj)
    {
        out << obj.data;
    }
};

template <typename T>
class HashLL
{
private:
    Node<T> *head;
    Node<T> *tail;

public:
    HashLL();
    HashLL(const HashLL<T> &);
    const HashLL<T> &operator=(const HashLL<T> &);
    ~HashLL();
    Node<T> *search(T);
    bool isEmpty();
    void insertAtTail(T);
    bool deleteAt(T);
    void print() const;
};
#endif
