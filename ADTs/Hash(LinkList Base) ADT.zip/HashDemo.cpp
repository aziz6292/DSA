// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#include "Hash.cpp"
int main()
{
    Hash<string> map(10);
    map.insert("BCSF19A026", 26);
    map.insert("BCSF19A027", 27);
    map.insert("BCSF19A028", 28);
    map.insert("BCSF19A029", 29);
    map.insert("BCSF19A030", 30);
    map.insert("BCSF19A031", 31);
    map.insert("BCSF19A032", 32);
    map.insert("BCSF19A033", 33);
    map.insert("BCSF19A034", 34);
    map.insert("BCSF19A035", 35);
    map.insert("BCSF19A036", 36);
    map.insert("BCSF19A037", 37);
    map.insert("BCSF19A038", 38);
    map.insert("BCSF19A039", 39);
    map.insert("BCSF19A040", 40);
    map.insert("BCSF19A041", 41);
    map.display();
    map.remove("BCSF19A029", 29);
    map.remove("BCSF19A033", 33);
    map.display();
    Node<string> *node = map.search("BCSF19A030", 30);
    if (node)
        cout << *node << endl;
    else
        cout << " Not found!" << endl;

    return 0;
}