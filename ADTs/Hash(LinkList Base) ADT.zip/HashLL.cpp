// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#include "HashLL.h"
template <typename T>
HashLL<T>::HashLL() : head(NULL), tail(NULL)
{
}
template <typename T>
HashLL<T>::HashLL(const HashLL<T> &obj) : HashLL()
{
    if (obj.head)
    {
        Node<T> *temp = obj.head;
        while (temp)
        {
            insertAtTail(temp->data);
            temp = temp->next;
        }
    }
}
template <typename T>
const HashLL<T> &HashLL<T>::operator=(const HashLL<T> &obj)
{
    if (this == &obj)
        return *this;
    if (!isEmpty())
    {
        this->~HashLL();
    }
    Node<T> *temp = obj.head;
    while (temp)
    {
        insertAtTail(temp->data);
        temp = temp->next;
    }
    return *this;
}
template <typename T>
HashLL<T>::~HashLL()
{
    Node<T> *cur = head;
    while (head != NULL)
    {
        head = head->next;
        delete cur;
        cur = head;
    }
    tail = NULL;
}
template <typename T>
Node<T> *HashLL<T>::search(T key)
{
    Node<T> *cur = head;
    if (!isEmpty())
        while (cur != NULL)
        {
            if (cur->data == key)
                return cur;
            cur = cur->next;
        }
    return cur;
}
template <typename T>
bool HashLL<T>::isEmpty()
{
    if (head == NULL)
        return true;
    return false;
}
template <typename T>
void HashLL<T>::insertAtTail(T value)
{
    Node<T> *cur = new Node<T>(value);
    if (isEmpty())
        head = tail = cur;
    else
    {
        tail->next = cur;
        tail = cur;
    }
}
template <typename T>
bool HashLL<T>::deleteAt(T key)
{
    Node<T> *cur = head;
    if (cur != NULL)
    {
        if (cur == head && cur == tail && cur->data == key)
        {
            delete cur;
            head = tail = cur = NULL;
            return true;
        }
        else if (cur == head && cur->data == key)
        {
            head = head->next;
            delete cur;
            cur = NULL;
            return true;
        }
        else
        {
            Node<T> *prev = head;
            if (head->next)
            {
                Node<T> *cur = head->next;
                while (cur)
                {
                    if (cur->data == key)
                    {
                        prev->next = cur->next;
                        return true;
                    }
                    prev = cur;
                    cur = cur->next;
                }
            }
            return false;
        }
    }
    else
        return false;
}
template <typename T>
void HashLL<T>::print() const
{
    Node<T> *cur = head;
    while (cur != NULL)
    {
        cout << cur->data << " ";
        cur = cur->next;
    }
    cout << endl;
}
