// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#include "Hash.h"
template <typename T>
Hash<T>::Hash(int s) : table(NULL), size(0), maxSize(0)
{
    if (s > 0)
    {
        maxSize = s;
        table = new HashLL<T>[maxSize];
    }
}
template <typename T>
Hash<T>::Hash(const Hash &obj)
{
    size = obj.size;
    maxSize = obj.maxSize;
    table = new HashLL<T>[maxSize];
    for (int i = 0; i < maxSize; i++)
        table[i] = obj.table[i];
}
template <typename T>
const Hash<T> &Hash<T>::operator=(const Hash<T> &obj)
{
    if (this == &obj)
        return *this;
    if (table)
        this->Hash();
    size = obj.size;
    maxSize = obj.maxSize;
    table = new HashLL<T>[maxSize];
    for (int i = 0; i < maxSize; i++)
        table[i] = obj.table[i];
    return *this;
}
template <typename T>
Hash<T>::~Hash()
{
    if (table)
    {
        for (int i = 0; i < maxSize; i++)
            table[i].~HashLL();
        delete[] table;
        table = NULL;
    }
}
template <typename T>
void Hash<T>::insert(T info, int index)
{
    int x = index % maxSize;
    table[x].insertAtTail(info);
}
template <typename T>
void Hash<T>::remove(T key, int index)
{
    int x = index % maxSize;
    if (table[x].deleteAt(key))
        cout << key << " deleted successfully" << endl;
    else
        cout << key << " not found" << endl;
}
template <typename T>
Node<T> *Hash<T>::search(T key, int index)
{
    int x = index % maxSize;
    return table[x].search(key);
}
template <typename T>
void Hash<T>::display()
{
    for (int i = 0; i < maxSize; i++)
        table[i].print();
}
