// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#ifndef HASHMAP_H
#define HASHMAP_H
#include <iostream>
using namespace std;

template <class T>
class HashMap
{
    T *table;
    int size;
    int maxSize;

public:
    HashMap(int = 0);
    HashMap(const HashMap &);
    const HashMap &operator=(const HashMap &);
    ~HashMap();
    bool insert(T);
    bool remove (T);
    bool search(T);
    bool isEmpty();
    bool isFull();
};
#endif