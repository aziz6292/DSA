// Abdul Aziz
// BCSF19A026
// CS Afternoon Add/Drop
#include "HashMap.h"

template <typename T>
HashMap<T>::HashMap(int N) : size(0), maxSize(0), table(NULL)
{
    if (N > 0)
    {
        maxSize = N;
        table = new T[maxSize];
        for (int i = 0; i < maxSize; i++)
            table[i] = -999;
    }
}
template <typename T>
HashMap<T>::HashMap(const HashMap &obj)
{
    maxSize = obj.maxSize;
    size = obj.size;
    table = new T[maxSize];
    for (int i = 0; i < maxSize; i++)
        table[i] = obj.table[i];
}
template <typename T>
const HashMap<T> &HashMap<T>::operator=(const HashMap<T> &obj)
{
    if (this == &obj)
        return *this;
    if (table)
        this->HashMap();
    maxSize = obj.maxSize;
    size = obj.size;
    table = new T[maxSize];
    for (int i = 0; i < maxSize; i++)
        table[i] = obj.table[i];
    return *this;
}
template <typename T>
HashMap<T>::~HashMap()
{
    if (table)
    {
        delete[] table;
        table = NULL;
    }
}
template <typename T>
bool HashMap<T>::insert(T val)
{
    T x = val % maxSize;
    cout << val << " " << x << " ";
    while (!(table[x] == -999 || table[x] == -9999))
        x = (x + 1) % maxSize;
    if (x == val % maxSize)
        cout << "const ";
    else
        cout << "Not a const ";
    table[x] = val;
    size++;
    return true;
}
template <typename T>
bool HashMap<T>::remove(T val)
{
    if (isEmpty())
        return false;
    T x = val % maxSize;
    bool flag = false;
    while (val != table[x] && !flag)
    {
        x = (x + 1) % maxSize;
        if (x == val%maxSize || table[x] == -999)
            flag = true;
    }
    if (val % maxSize == x)
        cout << "const ";
    else
        cout << "Not a const ";
    if (!flag)
    {
        table[x] = -9999;
        size--;
        return true;
    }
    else
        return false;
}
template <typename T>
bool HashMap<T>::search(T val)
{
    if (isEmpty())
        return false;
    T x = val % maxSize;
    bool flag = true;
    while (val != table[x] && flag)
    {
        x = (x + 1) % maxSize;
        if (x == val% maxSize || table[x] == -999)
            flag = false;
    }
    if (val% maxSize == x)
    cout << "const ";
    else cout << "Not a const ";
    if (flag)
        return true;
    else
        return false;
}
template <typename T>
bool HashMap<T>::isEmpty()
{
    return size == 0;
}
template <typename T>
bool HashMap<T>::isFull()
{
    return size == maxSize;
}